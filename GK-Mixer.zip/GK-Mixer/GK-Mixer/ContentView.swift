import SwiftUI

enum AppTab: String, CaseIterable {
    case workbench, tuning, palette, settings

    init(storedValue: String) {
        switch storedValue {
        case "extract", "mixer":
            self = .workbench
        case "blend", "basic":
            self = .tuning
        default:
            self = AppTab(rawValue: storedValue) ?? .workbench
        }
    }
}

struct ContentView: View {
    @AppStorage("selectedTabID") private var storedSelection = AppTab.workbench.rawValue
    @AppStorage("compactDockEnabled") private var compactDockEnabled = false

    private var selection: Binding<AppTab> {
        Binding(
            get: {
                let tab = AppTab(storedValue: storedSelection)
                if compactDockEnabled, tab == .settings {
                    return .workbench
                }
                return tab
            },
            set: { storedSelection = $0.rawValue }
        )
    }

    var body: some View {
        TabView(selection: selection) {
            Tab("混色台", systemImage: "flask.fill", value: .workbench) {
                MixerWorkbenchView()
            }
            Tab("调色", systemImage: "circle.grid.cross.fill", value: .tuning) {
                TuningWorkbenchView()
            }
            Tab("调色板", systemImage: "swatchpalette.fill", value: .palette) {
                PaletteView()
            }
            if !compactDockEnabled {
                Tab("设置", systemImage: "gearshape", value: .settings) {
                    SettingsView()
                }
            }
        }
        .tabBarMinimizeBehavior(.onScrollDown)
        .animation(AppAnimation.dockChrome, value: compactDockEnabled)
    }
}

#Preview {
    ContentView()
}

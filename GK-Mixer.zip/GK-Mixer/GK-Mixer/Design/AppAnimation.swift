import SwiftUI

enum AppAnimation {
    /// Tab bar / toolbar chrome when compact dock toggles.
    static let dockChrome: Animation = .smooth(duration: 0.42)
}

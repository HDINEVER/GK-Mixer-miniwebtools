import SwiftUI

/// Bundled Quicksand family (OFL). Registered via `UIAppFonts` in Info.plist.
///
/// Once registered, any view can call `AppFont.quicksand(...)` or
/// `Font.custom(AppFont.Name.semiBold.rawValue, size:)`.
enum AppFont {
    enum Name: String, CaseIterable {
        case light = "Quicksand-Light"
        case regular = "Quicksand-Regular"
        case medium = "Quicksand-Medium"
        case semiBold = "Quicksand-SemiBold"
        case bold = "Quicksand-Bold"
    }

    static func quicksand(_ name: Name = .regular, size: CGFloat) -> Font {
        .custom(name.rawValue, size: size)
    }

    /// Brand wordmark in the navigation bar.
    static var brandTitle: Font {
        quicksand(.semiBold, size: 22)
    }
}

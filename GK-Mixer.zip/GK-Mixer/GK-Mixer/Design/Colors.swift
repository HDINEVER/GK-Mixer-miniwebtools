import SwiftUI

/// Semantic color roles.
///
/// Pigment / swatch colors are deliberately absent: those come from color data
/// and must render true to the paint, unaffected by appearance. Everything that
/// is *chrome* — labels, backgrounds, accents — belongs here and adapts.
enum AppColor {
    /// Brand accent. Overridable at runtime via root `.tint` / Settings HEX.
    static let accent = Color.accentColor

    static let destructive = Color.red
    static let success = Color.green
    static let neutral = Color.secondary

    /// Base canvas behind grouped content cards.
    static let canvas = Color(.systemGroupedBackground)
    /// Content card surface.
    static let surface = Color(.secondarySystemGroupedBackground)
    /// Wells and placeholders nested inside a card.
    static let surfaceNested = Color(.tertiarySystemGroupedBackground)
}

/// User-selectable accent tint (Tab / selected controls). Matches `AccentColor` light.
enum AppAccent {
    static let storageKey = "accentHex"
    static let defaultHex = "#FF9900"

    static func color(hexStored: String) -> Color {
        Color(hex: Color.normalizedHex(hexStored) ?? defaultHex)
    }
}

/// Third-party brand colors — absolute by definition, exempt from the semantic rules.
enum BrandColor {
    static let bilibili = Color(hex: "#00A1D6")
    static let x = Color(hex: "#1DA1F2")
    static let qq = Color(hex: "#12B7F5")
}

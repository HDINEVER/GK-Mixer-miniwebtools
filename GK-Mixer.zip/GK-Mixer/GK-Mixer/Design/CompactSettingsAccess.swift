import SwiftUI

/// Navigation chrome shared by Tab 1–3: leading brand wordmark + optional
/// compact-dock circular settings control (FotMob-style).
struct CompactSettingsAccessModifier: ViewModifier {
    @AppStorage("compactDockEnabled") private var compactDockEnabled = false
    @AppStorage("openSettingsAfterCompact") private var openSettingsAfterCompact = false
    @State private var showingSettings = false

    /// Trailing glass control; ~15% larger than the previous 36pt circle.
    private let diameter: CGFloat = 36 * 1.15

    func body(content: Content) -> some View {
        content
            // Free horizontal space for the wordmark (center title was clipping it to “G…”).
            .navigationTitle("")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Text("GKMixer")
                        .font(AppFont.brandTitle)
                        .foregroundStyle(.primary)
                        .lineLimit(1)
                        .fixedSize(horizontal: true, vertical: false)
                        .accessibilityAddTraits(.isHeader)
                        .accessibilityLabel("GKMixer")
                }
                .sharedBackgroundVisibility(.hidden)

                if compactDockEnabled {
                    ToolbarItem(placement: .topBarTrailing) {
                        Button {
                            showingSettings = true
                        } label: {
                            Image(systemName: "line.3.horizontal")
                                .font(.system(size: 14, weight: .semibold))
                                .scaleEffect(x: 0.78, y: 1, anchor: .center)
                                .foregroundStyle(.primary)
                                .frame(width: diameter, height: diameter)
                                .glassEffect(.regular.interactive(), in: .circle)
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel(String(localized: "设置"))
                        .transition(
                            .scale(scale: 0.72, anchor: .trailing)
                                .combined(with: .opacity)
                        )
                    }
                    .sharedBackgroundVisibility(.hidden)
                }
            }
            .animation(AppAnimation.dockChrome, value: compactDockEnabled)
            .sheet(isPresented: $showingSettings) {
                SettingsView(isModal: true)
            }
            .onChange(of: compactDockEnabled) { _, enabled in
                // 4→3 handoff: after dock morphs, reopen Settings as the menu sheet.
                guard enabled, openSettingsAfterCompact else { return }
                openSettingsAfterCompact = false
                Task { @MainActor in
                    try? await Task.sleep(for: .milliseconds(240))
                    showingSettings = true
                }
            }
    }
}

extension View {
    func compactSettingsAccess() -> some View {
        modifier(CompactSettingsAccessModifier())
    }
}

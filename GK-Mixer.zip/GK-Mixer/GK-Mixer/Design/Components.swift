import SwiftUI
import UIKit

// MARK: - Content card

/// Grouped content surface. Deliberately *not* glass: per the layering model,
/// glass belongs to the functional layer (tab bar, toolbars, floating controls),
/// while content sits on an opaque semantic surface.
struct ContentCardModifier: ViewModifier {
    var cornerRadius: CGFloat = CornerRadius.card
    var padding: CGFloat = Spacing.md

    func body(content: Content) -> some View {
        content
            .padding(padding)
            .frame(maxWidth: .infinity)
            .background(
                RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                    .fill(AppColor.surface)
            )
    }
}

extension View {
    func contentCard(
        cornerRadius: CGFloat = CornerRadius.card,
        padding: CGFloat = Spacing.md
    ) -> some View {
        modifier(ContentCardModifier(cornerRadius: cornerRadius, padding: padding))
    }
}

// MARK: - Section header

struct SectionHeader: View {
    let title: LocalizedStringKey
    var icon: String? = nil

    var body: some View {
        HStack(spacing: Spacing.xxs + 2) {
            if let icon {
                Image(systemName: icon)
                    .imageScale(.small)
            }
            Text(title)
        }
        .font(.footnote.weight(.semibold))
        .foregroundStyle(.secondary)
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

// MARK: - Placeholder well

/// Empty drop target inside a card — an image slot, a preview area, a swatch slot.
struct PlaceholderWell<Content: View>: View {
    var cornerRadius: CGFloat = CornerRadius.well
    @ViewBuilder var content: Content

    var body: some View {
        RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
            .fill(AppColor.surfaceNested)
            .overlay(content)
    }
}

// MARK: - Empty state

struct EmptyStateCard: View {
    let emoji: String
    let title: LocalizedStringKey
    let subtitle: LocalizedStringKey

    var body: some View {
        VStack(spacing: Spacing.sm) {
            Text(emoji)
                .font(.system(size: 52))

            Text(title)
                .font(.title3.bold())

            Text(subtitle)
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, Spacing.xl)
    }
}

// MARK: - Action button

/// Functional-layer control, so it *is* glass — via the system button style
/// rather than a hand-rolled material capsule.
struct ActionButton: View {
    let title: String
    let icon: String
    var tint: Color = AppColor.accent
    var isProminent: Bool = false
    var action: () -> Void = {}

    var body: some View {
        Group {
            if isProminent {
                Button(title, systemImage: icon, action: action)
                    .buttonStyle(.glassProminent)
            } else {
                Button(title, systemImage: icon, action: action)
                    .buttonStyle(.glass)
            }
        }
        .controlSize(.large)
        .tint(tint)
        .frame(maxWidth: .infinity)
    }
}

// MARK: - Copyable HEX chip

/// Glass capsule that copies a hex string on tap with a light impact haptic.
struct CopyableHexChip: View {
    let hex: String
    var font: Font = .headline.monospaced()

    @State private var copyTrigger = 0

    var body: some View {
        Button {
            UIPasteboard.general.string = hex
            copyTrigger += 1
        } label: {
            Text(hex)
                .font(font)
                .padding(.horizontal, Spacing.sm)
                .padding(.vertical, Spacing.xs)
                .glassEffect(.regular, in: .capsule)
        }
        .buttonStyle(.plain)
        .sensoryFeedback(.impact(flexibility: .soft, intensity: 0.55), trigger: copyTrigger)
        .accessibilityLabel(L10n.colorCode(hex))
        .accessibilityHint(String(localized: "点按复制"))
    }
}

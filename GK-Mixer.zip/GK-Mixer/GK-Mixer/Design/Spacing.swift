import CoreGraphics

/// Layout spacing tokens. Every padding / stack spacing in the app resolves to
/// one of these — see `LIQUID_GLASS_UI_REFERENCE.md` §2.1.
enum Spacing {
    static let xxs: CGFloat = 4
    static let xs: CGFloat = 8
    static let sm: CGFloat = 12
    static let md: CGFloat = 16
    static let lg: CGFloat = 20
    static let xl: CGFloat = 24
    static let xxl: CGFloat = 32

    /// HIG minimum hit target.
    static let touch: CGFloat = 44
}

/// Corner radii. Nested shapes should derive their radius from the parent
/// (`outer - padding`) rather than declaring an unrelated constant.
enum CornerRadius {
    static let card: CGFloat = 20
    static let well: CGFloat = 14
    static let swatch: CGFloat = 10

    /// Concentric inner radius for a shape inset by `padding` inside `outer`.
    static func inner(of outer: CGFloat, padding: CGFloat) -> CGFloat {
        max(0, outer - padding)
    }
}

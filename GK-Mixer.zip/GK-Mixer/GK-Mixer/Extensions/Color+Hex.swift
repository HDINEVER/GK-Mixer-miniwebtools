import SwiftUI

extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 6:
            (a, r, g, b) = (255, (int >> 16) & 0xFF, (int >> 8) & 0xFF, int & 0xFF)
        case 8:
            (a, r, g, b) = ((int >> 24) & 0xFF, (int >> 16) & 0xFF, (int >> 8) & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (255, 0, 0, 0)
        }
        self.init(
            .sRGB,
            red: Double(r) / 255,
            green: Double(g) / 255,
            blue: Double(b) / 255,
            opacity: Double(a) / 255
        )
    }

    /// Returns `#RRGGBB` when `raw` is a valid 6-digit (or 8-digit ARGB) hex; otherwise `nil`.
    static func normalizedHex(_ raw: String) -> String? {
        let hex = raw
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
            .uppercased()
        guard hex.count == 6 || hex.count == 8,
              hex.allSatisfy(\.isHexDigit)
        else { return nil }
        let rgb = hex.count == 8 ? String(hex.suffix(6)) : hex
        return "#\(rgb)"
    }
}

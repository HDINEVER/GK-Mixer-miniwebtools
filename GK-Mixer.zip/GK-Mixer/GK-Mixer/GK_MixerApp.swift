import SwiftUI
import SwiftData

@main
struct GK_MixerApp: App {
    @AppStorage("colorScheme") private var appearance: Appearance = .system
    @AppStorage(AppAccent.storageKey) private var accentHex = AppAccent.defaultHex
    private let modelContainer: ModelContainer
    @State private var paletteStore: PaletteStore
    @State private var workbenchStore = WorkbenchStore()
    @State private var basicMixerStore = BasicMixerStore()
    @State private var blendStore = BlendStore()

    init() {
        do {
            let container = try ModelContainer(
                for: SavedColor.self,
                PaletteCategory.self
            )
            modelContainer = container
            _paletteStore = State(
                initialValue: PaletteStore(modelContext: container.mainContext)
            )
        } catch {
            fatalError("Unable to create palette database: \(error)")
        }
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(appearance.colorScheme)
                .tint(AppAccent.color(hexStored: accentHex))
                .environment(paletteStore)
                .environment(workbenchStore)
                .environment(basicMixerStore)
                .environment(blendStore)
        }
        .modelContainer(modelContainer)
    }
}

enum Appearance: String, CaseIterable, Identifiable {
    case system, light, dark

    var id: Self { self }

    var label: String {
        switch self {
        case .system: String(localized: "跟随系统")
        case .light: String(localized: "浅色")
        case .dark: String(localized: "深色")
        }
    }

    var colorScheme: ColorScheme? {
        switch self {
        case .system: nil
        case .light: .light
        case .dark: .dark
        }
    }
}

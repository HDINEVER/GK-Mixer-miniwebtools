import Foundation

/// Helpers for format strings and String-typed localized copy.
/// Plain `Text("…")` / `Label("…")` literals resolve via `Localizable.xcstrings`.
enum L10n {
    static func tr(_ key: String.LocalizationValue) -> String {
        String(localized: key)
    }

    static func addedToCustomMix(hex: String) -> String {
        String(format: String(localized: "已加入自选调色：%@"), hex)
    }

    static func saveFailed(_ message: String) -> String {
        String(format: String(localized: "保存失败：%@"), message)
    }

    static func customMixAtCapacity(_ max: Int) -> String {
        String(format: String(localized: "自选调色最多 %lld 种颜色"), max)
    }

    static func maxColors(_ max: Int) -> String {
        String(format: String(localized: "最多添加 %lld 种颜色"), max)
    }

    static func colorCode(_ hex: String) -> String {
        String(format: String(localized: "颜色代码 %@"), hex)
    }

    static func milliliters(_ value: String) -> String {
        String(format: String(localized: "%@ 毫升"), value)
    }

    static func baseCoat(_ code: String) -> String {
        String(format: String(localized: "底漆: %@"), code)
    }

    static func deleteCategoryConfirm(_ name: String) -> String {
        String(format: String(localized: "删除分类“%@”？"), name)
    }

    static func removeColor(_ name: String) -> String {
        String(format: String(localized: "移除 %@"), name)
    }

    static func algorithmFailed(_ message: String) -> String {
        String(format: String(localized: "颜色算法执行失败：%@"), message)
    }

    static func unsupportedAlgorithmVersion(_ version: Int) -> String {
        String(format: String(localized: "颜色算法版本不受支持：%lld"), version)
    }

    /// Persistable sentinel — do not localize for storage comparisons.
    static let untitledColorSentinel = "未命名颜色"

    static var untitledColor: String {
        String(localized: "未命名颜色")
    }

    static func localizedPigmentName(_ name: String) -> String {
        String(localized: String.LocalizationValue(name))
    }

    static func displayColorName(_ name: String) -> String {
        name == untitledColorSentinel ? untitledColor : name
    }
}

// GK-Mixer: Color Data Models
// Ported 1:1 from @gk-mixer/core types/color.ts
// Zero external dependencies — pure Swift data contracts.

import Foundation

struct RGB: Codable, Equatable { var r, g, b: Int }
struct CMYK: Codable, Equatable { var c, m, y, k: Int }
struct HSB: Codable, Equatable { var h, s, b: Int }
struct LAB: Codable, Equatable { var l, a, b: Double }

struct ColorData: Identifiable, Codable, Equatable {
    var id = UUID().uuidString
    var hex: String
    var rgb: RGB
    var cmyk: CMYK
    var hsb: HSB
    var lab: LAB
    var source: Source = .auto

    enum Source: String, Codable { case auto, manual }
}

struct PaintBrand: Identifiable, Codable, Equatable {
    var id: String
    var brand: Brand
    var code: String
    var name: String
    var hex: String

    enum Brand: String, Codable {
        case gaia = "Gaia"
        case jumpwind = "Jumpwind"
        case gunze = "Gunze"
        case cmySolid = "CMY Solid"
        case cmyPigment = "CMY Pigment"
    }
}

// RAL standard color
struct RALColor: Identifiable, Codable, Equatable {
    var id: String { "\(ral)" }
    var ral: Int
    var name: String
    var hex: String
    var rgb: RGB
}

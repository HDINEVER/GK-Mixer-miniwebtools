import Foundation
import SwiftData

enum MixboxPaletteID: String, Codable, Equatable {
    case gaiaProcess8
    case legacyExtended8
}

/// Stable, versioned snapshot of the pigments used to reproduce a Mixbox color.
struct MixboxRecipeSnapshot: Codable, Equatable {
    static let currentVersion = 2

    var version: Int = currentVersion
    var paletteID: MixboxPaletteID = .gaiaProcess8
    var components: [MixboxRecipeComponent]

    static let gaiaProcessPigments: [(id: String, name: String, hex: String)] = [
        ("white", "白", "#FFFFFF"),
        ("black", "黑", "#000000"),
        ("red", "红", "#E60012"),
        ("blue", "蓝", "#004098"),
        ("yellow", "黄", "#FFD900"),
        ("sourceYellow", "色源黄", "#FFEF00"),
        ("sourceCyan", "色源青", "#00B7EB"),
        ("sourceMagenta", "色源品红", "#FF0090"),
    ]

    static let legacyExtendedPigments: [(id: String, name: String, hex: String)] = [
        ("legacy-001", "纯白", "#FFFFFF"),
        ("legacy-002", "纯黑", "#000000"),
        ("legacy-003", "红色", "#FF0000"),
        ("legacy-006", "品红", "#FF00FF"),
        ("legacy-004", "蓝色", "#0000FF"),
        ("legacy-007", "青色", "#00FFFF"),
        ("legacy-005", "黄色", "#FFFF00"),
        ("legacy-008", "橙色", "#FF8000"),
    ]

    /// Compatibility alias for existing Gaia/Process callers.
    static let pigmentOrder = gaiaProcessPigments

    static var empty: MixboxRecipeSnapshot {
        MixboxRecipeSnapshot(
            paletteID: .gaiaProcess8,
            components: gaiaProcessPigments.map {
                MixboxRecipeComponent(id: $0.id, name: $0.name, hex: $0.hex, weight: 0)
            }
        )
    }

    func normalized() -> MixboxRecipeSnapshot {
        let total = components.reduce(0) { $0 + max(0, $1.weight) }
        guard total > 0 else { return self }

        return MixboxRecipeSnapshot(
            version: version,
            paletteID: paletteID,
            components: components.map {
                MixboxRecipeComponent(
                    id: $0.id,
                    name: $0.name,
                    hex: $0.hex,
                    weight: max(0, $0.weight) / total
                )
            }
        )
    }

    private enum CodingKeys: String, CodingKey {
        case version
        case paletteID
        case components
    }

    init(
        version: Int = currentVersion,
        paletteID: MixboxPaletteID = .gaiaProcess8,
        components: [MixboxRecipeComponent]
    ) {
        self.version = version
        self.paletteID = paletteID
        self.components = components
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        version = try container.decodeIfPresent(Int.self, forKey: .version) ?? 1
        paletteID = try container.decodeIfPresent(MixboxPaletteID.self, forKey: .paletteID)
            ?? .gaiaProcess8
        components = try container.decode([MixboxRecipeComponent].self, forKey: .components)
    }
}

struct MixboxRecipeComponent: Codable, Equatable, Identifiable {
    var id: String
    var name: String
    var hex: String
    var weight: Double
}

struct RALMatchSnapshot: Codable, Equatable {
    var number: Int
    var name: String
    var lrv: Double
    var standardHex: String

    var displayName: String {
        "RAL \(number) \(name)"
    }
}

@Model
final class PaletteCategory {
    @Attribute(.unique) var id: UUID
    @Attribute(.unique) var normalizedName: String
    var name: String
    var sortOrder: Int
    var createdAt: Date

    init(name: String, sortOrder: Int) {
        id = UUID()
        self.name = name.trimmingCharacters(in: .whitespacesAndNewlines)
        normalizedName = Self.normalize(name)
        self.sortOrder = sortOrder
        createdAt = .now
    }

    static func normalize(_ name: String) -> String {
        name.trimmingCharacters(in: .whitespacesAndNewlines)
            .folding(options: [.caseInsensitive, .diacriticInsensitive], locale: .current)
            .lowercased()
    }
}

@Model
final class SavedColor {
    @Attribute(.unique) var id: UUID
    @Attribute(.unique) var normalizedHex: String
    var name: String
    var recipeData: Data?
    var ralData: Data?
    var createdAt: Date
    var updatedAt: Date
    var category: PaletteCategory?

    init(
        hex: String,
        name: String,
        recipe: MixboxRecipeSnapshot?,
        ralMatch: RALMatchSnapshot? = nil,
        category: PaletteCategory? = nil
    ) {
        id = UUID()
        normalizedHex = HexColor.normalize(hex) ?? "#000000"
        self.name = name.trimmingCharacters(in: .whitespacesAndNewlines)
        recipeData = recipe.flatMap { try? JSONEncoder().encode($0.normalized()) }
        ralData = ralMatch.flatMap { try? JSONEncoder().encode($0) }
        createdAt = .now
        updatedAt = .now
        self.category = category
    }

    var recipe: MixboxRecipeSnapshot? {
        get {
            guard let recipeData else { return nil }
            return try? JSONDecoder().decode(MixboxRecipeSnapshot.self, from: recipeData)
        }
        set {
            recipeData = newValue.flatMap { try? JSONEncoder().encode($0.normalized()) }
            updatedAt = .now
        }
    }

    var ralMatch: RALMatchSnapshot? {
        get {
            guard let ralData else { return nil }
            return try? JSONDecoder().decode(RALMatchSnapshot.self, from: ralData)
        }
        set {
            ralData = newValue.flatMap { try? JSONEncoder().encode($0) }
            updatedAt = .now
        }
    }
}

enum HexColor {
    static func normalize(_ value: String) -> String? {
        let cleaned = value
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: "#", with: "")
            .uppercased()

        guard cleaned.count == 6,
              cleaned.allSatisfy(\.isHexDigit) else {
            return nil
        }
        return "#\(cleaned)"
    }
}

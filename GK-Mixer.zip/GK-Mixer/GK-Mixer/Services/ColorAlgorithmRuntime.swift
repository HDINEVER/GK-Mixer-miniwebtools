import Foundation
import JavaScriptCore

struct BasicMixResult: Codable, Equatable {
    var hex: String
    var components: [MixboxRecipeComponent]

    var recipe: MixboxRecipeSnapshot {
        MixboxRecipeSnapshot(
            paletteID: .gaiaProcess8,
            components: components
        ).normalized()
    }
}

struct MultiMixResult: Codable, Equatable {
    var hex: String
}

enum ColorAlgorithmError: LocalizedError {
    case bundleMissing
    case contextCreationFailed
    case invalidBundleVersion(Int)
    case bridgeUnavailable
    case javaScript(String)
    case malformedResponse

    var errorDescription: String? {
        switch self {
        case .bundleMissing:
            String(localized: "找不到内置颜色算法资源")
        case .contextCreationFailed:
            String(localized: "无法启动颜色算法运行环境")
        case .invalidBundleVersion(let version):
            L10n.unsupportedAlgorithmVersion(version)
        case .bridgeUnavailable:
            String(localized: "颜色算法接口不可用")
        case .javaScript(let message):
            L10n.algorithmFailed(message)
        case .malformedResponse:
            String(localized: "颜色算法返回了无效数据")
        }
    }
}

actor ColorAlgorithmRuntime {
    static let shared = ColorAlgorithmRuntime()
    static let supportedBundleVersion = 1

    private var context: JSContext?
    private var invocationFunction: JSValue?
    private var lastException: String?

    func decompose(hex: String) throws -> MixboxRecipeSnapshot {
        let components: [MixboxRecipeComponent] = try invoke(
            method: "decompose8",
            payload: ["hex": hex, "colorSpace": "srgb"]
        )
        guard components.count == 8 else {
            throw ColorAlgorithmError.malformedResponse
        }
        return MixboxRecipeSnapshot(
            paletteID: .legacyExtended8,
            components: components
        ).normalized()
    }

    func mixBasic(weights: [Double]) throws -> BasicMixResult? {
        try invokeOptional(method: "mixBasic", payload: ["weights": weights])
    }

    /// Mixbox latent-space blend of arbitrary colors (web `mixboxMultiBlend`).
    func mixMulti(colors: [(hex: String, weight: Double)]) throws -> MultiMixResult? {
        let payloadColors: [[String: Any]] = colors.map { entry in
            ["hex": entry.hex, "weight": entry.weight]
        }
        return try invokeOptional(
            method: "mixMulti",
            payload: ["colors": payloadColors]
        )
    }

    func nearestRAL(hex: String) throws -> RALMatchSnapshot? {
        try invokeOptional(method: "findNearestRAL", payload: ["hex": hex])
    }

    func bundleVersion() throws -> Int {
        try invoke(method: "bundleVersion", payload: [:])
    }

    private func prepareIfNeeded() throws {
        guard context == nil else { return }
        guard let scriptURL = bundleURL() else {
            throw ColorAlgorithmError.bundleMissing
        }
        guard let source = try? String(contentsOf: scriptURL, encoding: .utf8),
              let jsContext = JSContext() else {
            throw ColorAlgorithmError.contextCreationFailed
        }

        lastException = nil
        jsContext.exceptionHandler = { [weak self] _, exception in
            let message = exception?.toString() ?? "Unknown JavaScript exception"
            Task { await self?.recordException(message) }
        }
        jsContext.evaluateScript(source, withSourceURL: scriptURL)
        if let lastException {
            throw ColorAlgorithmError.javaScript(lastException)
        }

        guard let function = jsContext
            .objectForKeyedSubscript("GKColorAlgorithms")?
            .objectForKeyedSubscript("invoke"),
              !function.isUndefined else {
            throw ColorAlgorithmError.bridgeUnavailable
        }

        context = jsContext
        invocationFunction = function
        let version: Int = try invokePrepared(method: "bundleVersion", payload: [:])
        guard version == Self.supportedBundleVersion else {
            context = nil
            invocationFunction = nil
            throw ColorAlgorithmError.invalidBundleVersion(version)
        }
    }

    private func recordException(_ message: String) {
        lastException = message
    }

    private func bundleURL() -> URL? {
        Bundle.main.url(
            forResource: "gk-color-algorithms",
            withExtension: "js",
            subdirectory: "Resources"
        ) ?? Bundle.main.url(
            forResource: "gk-color-algorithms",
            withExtension: "js"
        )
    }

    private func invoke<Value: Decodable>(
        method: String,
        payload: [String: Any],
        as type: Value.Type = Value.self
    ) throws -> Value {
        try prepareIfNeeded()
        return try invokePrepared(method: method, payload: payload, as: type)
    }

    private func invokeOptional<Value: Decodable>(
        method: String,
        payload: [String: Any],
        as type: Value.Type = Value.self
    ) throws -> Value? {
        try prepareIfNeeded()
        let rawValue = try invokeRaw(method: method, payload: payload)
        guard !(rawValue is NSNull) else { return nil }
        return try decode(rawValue, as: type)
    }

    private func invokePrepared<Value: Decodable>(
        method: String,
        payload: [String: Any],
        as type: Value.Type = Value.self
    ) throws -> Value {
        let rawValue = try invokeRaw(method: method, payload: payload)
        guard !(rawValue is NSNull) else {
            throw ColorAlgorithmError.malformedResponse
        }
        return try decode(rawValue, as: type)
    }

    private func invokeRaw(method: String, payload: [String: Any]) throws -> Any {
        guard let invocationFunction else {
            throw ColorAlgorithmError.bridgeUnavailable
        }
        let requestData = try JSONSerialization.data(
            withJSONObject: ["method": method, "payload": payload]
        )
        guard let request = String(data: requestData, encoding: .utf8) else {
            throw ColorAlgorithmError.malformedResponse
        }

        lastException = nil
        guard let responseString = invocationFunction.call(withArguments: [request])?.toString(),
              let responseData = responseString.data(using: .utf8),
              let response = try JSONSerialization.jsonObject(with: responseData)
                as? [String: Any] else {
            throw ColorAlgorithmError.malformedResponse
        }
        if let lastException {
            throw ColorAlgorithmError.javaScript(lastException)
        }
        guard response["ok"] as? Bool == true else {
            throw ColorAlgorithmError.javaScript(
                response["error"] as? String ?? "Unknown bridge error"
            )
        }
        guard let value = response["value"] else {
            throw ColorAlgorithmError.malformedResponse
        }
        return value
    }

    private func decode<Value: Decodable>(_ value: Any, as type: Value.Type) throws -> Value {
        let data = try JSONSerialization.data(withJSONObject: value, options: [.fragmentsAllowed])
        return try JSONDecoder().decode(type, from: data)
    }
}

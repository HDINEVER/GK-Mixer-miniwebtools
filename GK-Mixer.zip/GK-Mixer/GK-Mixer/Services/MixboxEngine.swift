import Foundation

/// Mixbox 2.0 前向混色模型的最小闭包。
///
/// 八种颜料的七维潜变量由原版 Mixbox 2.0 LUT 计算得到；任意配方先在潜空间
/// 线性混合，再通过原版三次多项式还原 sRGB。这样运行时无需携带约 0.75 MB LUT，
/// 同时配方的前向结果与完整 Mixbox 实现一致（仅有 Double 浮点舍入差异）。
enum MixboxEngine {
    struct RGB: Equatable {
        let r: Double
        let g: Double
        let b: Double
    }

    struct Pigment {
        let id: String
        let hex: String
        fileprivate let latent: [Double]
    }

    static let pigments: [Pigment] = [
        Pigment(id: "white", hex: "#FFFFFF", latent: [
            0, 0, 0, 1,
            0.004818619999999996, 0.00021850999999994958, 0.002951979999999965,
        ]),
        Pigment(id: "black", hex: "#000000", latent: [
            0.48627450980392156, 0.2627450980392157, 0.24705882352941178, 0.0039215686274509665,
            -0.22201499367911712, -0.2212965645869248, -0.22017006699691552,
        ]),
        Pigment(id: "red", hex: "#E60012", latent: [
            0, 0.1655824682814303, 0.810269353416107, 0.02414817830246274,
            0.057702259431918534, -0.11629189558101603, 0.016149976561675883,
        ]),
        Pigment(id: "blue", hex: "#004098", latent: [
            0.8100576701268742, 0.027727797001153402, 0.0007381776239907702, 0.16147635524798165,
            -0.043222008425239045, 0.00007486679801671503, -0.0016922511799307705,
        ]),
        Pigment(id: "yellow", hex: "#FFD900", latent: [
            0.00392156862745098, 0.9143713956170705, 0.0015224913494809773, 0.08018454440599754,
            0.042990661828090304, 0.04096234699790813, -0.06193694166849634,
        ]),
        Pigment(id: "sourceYellow", hex: "#FFEF00", latent: [
            0.00392156862745098, 0.8506113033448672, 0, 0.1454671280276818,
            0.036093980838802664, 0.11310147370555346, -0.08422724064730817,
        ]),
        Pigment(id: "sourceCyan", hex: "#00B7EB", latent: [
            0.5197258972793269, 0.027220299884659762, 0, 0.45305380283601326,
            -0.2067186768451722, 0.17261550070698417, 0.02720393384731179,
        ]),
        Pigment(id: "sourceMagenta", hex: "#FF0090", latent: [
            0.011764705882352941, 0, 0.6582237600922722, 0.33001153402537486,
            0.11634774404899118, -0.25440250672172043, 0.12914232495130945,
        ]),
    ]

    /// 使用八个非负权重执行真实 Mixbox 前向混色。权重会自动归一化。
    static func mix(weights: [Double]) -> RGB? {
        guard weights.count == pigments.count else { return nil }

        let nonnegative = weights.map { max(0, $0) }
        let total = nonnegative.reduce(0, +)
        guard total.isFinite, total > 0 else { return nil }

        var latent = Array(repeating: 0.0, count: 7)
        for (pigment, rawWeight) in zip(pigments, nonnegative) {
            let weight = rawWeight / total
            for channel in latent.indices {
                latent[channel] += pigment.latent[channel] * weight
            }
        }
        return rgb(from: latent)
    }

    /// 严格解析 `RRGGBB` 或 `#RRGGBB`；无效输入返回 nil。
    static func parse(hex: String) -> RGB? {
        let trimmed = hex.trimmingCharacters(in: .whitespacesAndNewlines)
        let value = trimmed.hasPrefix("#") ? String(trimmed.dropFirst()) : trimmed
        guard value.count == 6, value.allSatisfy(\.isHexDigit),
              let packed = Int(value, radix: 16) else {
            return nil
        }

        return RGB(
            r: Double((packed >> 16) & 0xFF) / 255,
            g: Double((packed >> 8) & 0xFF) / 255,
            b: Double(packed & 0xFF) / 255
        )
    }

    private static func rgb(from latent: [Double]) -> RGB {
        let polynomial = evaluatePolynomial(
            c0: latent[0],
            c1: latent[1],
            c2: latent[2],
            c3: latent[3]
        )
        return RGB(
            r: clamp01(polynomial.r + latent[4]),
            g: clamp01(polynomial.g + latent[5]),
            b: clamp01(polynomial.b + latent[6])
        )
    }

    // Coefficients copied from Mixbox 2.0 evalPolynomial.
    private static func evaluatePolynomial(c0: Double, c1: Double, c2: Double, c3: Double) -> RGB {
        let c00 = c0 * c0
        let c11 = c1 * c1
        let c22 = c2 * c2
        let c33 = c3 * c3
        let c01 = c0 * c1
        let c02 = c0 * c2
        let c12 = c1 * c2

        let terms: [(Double, Double, Double, Double)] = [
            (c0 * c00, 0.07717053, 0.02826978, 0.24832992),
            (c1 * c11, 0.95912302, 0.80256528, 0.03561839),
            (c2 * c22, 0.74683774, 0.04868586, 0),
            (c3 * c33, 0.99518138, 0.99978149, 0.99704802),
            (c00 * c1, 0.04819146, 0.83363781, 0.32515377),
            (c01 * c1, -0.68146950, 1.46107803, 1.06980936),
            (c00 * c2, 0.27058419, -0.15324870, 1.98735057),
            (c02 * c2, 0.80478189, 0.67093710, 0.18424500),
            (c00 * c3, -0.35031003, 1.37855826, 3.68865000),
            (c0 * c33, 1.05128046, 1.97815239, 2.82989073),
            (c11 * c2, 3.21607125, 0.81270228, 1.03384539),
            (c1 * c22, 2.78893374, 0.41565549, -0.04487295),
            (c11 * c3, 3.02162577, 2.55374103, 0.32766114),
            (c1 * c33, 2.95124691, 2.81201112, 1.17578442),
            (c22 * c3, 2.82677043, 0.79933038, 1.81715262),
            (c2 * c33, 2.99691099, 1.22593053, 1.80653661),
            (c01 * c2, 1.87394106, 2.05027182, -0.29835996),
            (c01 * c3, 2.56609566, 7.03428198, 0.62575374),
            (c02 * c3, 4.08329484, -1.40408358, 2.14995522),
            (c12 * c3, 6.00078678, 2.55552042, 1.90739502),
        ]

        var result = RGB(r: 0, g: 0, b: 0)
        for (weight, r, g, b) in terms {
            result = RGB(
                r: result.r + r * weight,
                g: result.g + g * weight,
                b: result.b + b * weight
            )
        }
        return result
    }

    private static func clamp01(_ value: Double) -> Double {
        min(1, max(0, value))
    }
}

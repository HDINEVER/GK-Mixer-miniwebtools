import Foundation

struct MixboxSolvedComponent: Equatable {
    let id: String
    let weight: Double
}

/// 从目标 sRGB 颜色反求八色 Mixbox 配方。
enum MixboxRecipeSolver {
    /// 求解目标 HEX 的八色配方。
    ///
    /// - Important: 输入只接受 `RRGGBB` 或 `#RRGGBB`。无效 HEX 安全返回空数组。
    /// - Returns: 固定顺序的八个分量；每项位于 0...1，且总和约等于 1。
    static func solve(hex: String) -> [MixboxSolvedComponent] {
        guard let target = MixboxEngine.parse(hex: hex) else { return [] }

        // 基色是配方空间的顶点，直接返回顶点可避免优化器在近似等价颜料间分摊。
        if let exactIndex = exactPigmentIndex(for: target) {
            return components(from: oneHot(index: exactIndex))
        }

        let targetLab = okLab(target)
        let starts = initialWeights(for: target)
        var bestWeights = starts[0]
        var bestError = objective(weights: bestWeights, target: target, targetLab: targetLab)

        for start in starts {
            let candidate = optimize(start: start, target: target, targetLab: targetLab)
            let error = objective(weights: candidate, target: target, targetLab: targetLab)
            if error < bestError {
                bestWeights = candidate
                bestError = error
            }
        }

        return components(from: normalize(bestWeights))
    }

    private static func exactPigmentIndex(for target: MixboxEngine.RGB) -> Int? {
        MixboxEngine.pigments.firstIndex {
            guard let rgb = MixboxEngine.parse(hex: $0.hex) else { return false }
            return abs(rgb.r - target.r) < 0.5 / 255
                && abs(rgb.g - target.g) < 0.5 / 255
                && abs(rgb.b - target.b) < 0.5 / 255
        }
    }

    private static func initialWeights(for target: MixboxEngine.RGB) -> [[Double]] {
        let count = MixboxEngine.pigments.count
        let nearest = MixboxEngine.pigments.enumerated().min { lhs, rhs in
            rgbDistance(target, MixboxEngine.parse(hex: lhs.element.hex)!)
                < rgbDistance(target, MixboxEngine.parse(hex: rhs.element.hex)!)
        }?.offset ?? 0

        var starts = [
            oneHot(index: nearest),
            Array(repeating: 1 / Double(count), count: count),
        ]

        // 一个明暗无彩初始化可显著改善低饱和颜色的收敛。
        let luminance = 0.2126 * target.r + 0.7152 * target.g + 0.0722 * target.b
        var grayscale = Array(repeating: 0.0, count: count)
        grayscale[0] = luminance
        grayscale[1] = 1 - luminance
        starts.append(grayscale)
        return starts
    }

    /// 在概率单纯形上做确定性的成对坐标下降。
    ///
    /// 每一步只把颜料从一个分量转移到另一个分量，因此始终满足非负与总和为 1。
    /// 目标函数由 Mixbox 前向结果计算，而非 RGB/CMYK 比例公式。
    private static func optimize(
        start: [Double],
        target: MixboxEngine.RGB,
        targetLab: OKLab
    ) -> [Double] {
        var weights = normalize(start)
        var currentError = objective(weights: weights, target: target, targetLab: targetLab)
        var step = 0.25

        while step >= 1.0 / 4096 {
            for _ in 0..<24 {
                var bestTrial: [Double]?
                var bestTrialError = currentError

                for donor in weights.indices where weights[donor] > 0 {
                    let amount = min(step, weights[donor])
                    guard amount > 0 else { continue }

                    for receiver in weights.indices where receiver != donor {
                        var trial = weights
                        trial[donor] -= amount
                        trial[receiver] += amount
                        let error = objective(weights: trial, target: target, targetLab: targetLab)
                        if error + 1e-14 < bestTrialError {
                            bestTrial = trial
                            bestTrialError = error
                        }
                    }
                }

                guard let bestTrial else { break }
                weights = bestTrial
                currentError = bestTrialError
            }

            // 固定减半并限制每级迭代数，保证 UI 调用耗时可预测。
            step *= 0.5
        }
        return weights
    }

    private static func objective(
        weights: [Double],
        target: MixboxEngine.RGB,
        targetLab: OKLab
    ) -> Double {
        guard let mixed = MixboxEngine.mix(weights: weights) else {
            return .greatestFiniteMagnitude
        }
        let mixedLab = okLab(mixed)
        let dL = mixedLab.l - targetLab.l
        let dA = mixedLab.a - targetLab.a
        let dB = mixedLab.b - targetLab.b

        // OKLab 主导感知匹配，少量 sRGB 项帮助钳位边界处保持通道精度。
        let perceptual = dL * dL + dA * dA + dB * dB
        let rgb = rgbDistance(mixed, target)
        return perceptual + 0.025 * rgb
    }

    private static func components(from weights: [Double]) -> [MixboxSolvedComponent] {
        zip(MixboxEngine.pigments, weights).map {
            MixboxSolvedComponent(id: $0.0.id, weight: $0.1)
        }
    }

    private static func oneHot(index: Int) -> [Double] {
        var weights = Array(repeating: 0.0, count: MixboxEngine.pigments.count)
        weights[index] = 1
        return weights
    }

    private static func normalize(_ weights: [Double]) -> [Double] {
        let values = weights.map { max(0, $0.isFinite ? $0 : 0) }
        let total = values.reduce(0, +)
        guard total > 0 else {
            return Array(repeating: 1 / Double(values.count), count: values.count)
        }
        return values.map { $0 / total }
    }

    private static func rgbDistance(_ lhs: MixboxEngine.RGB, _ rhs: MixboxEngine.RGB) -> Double {
        let dr = lhs.r - rhs.r
        let dg = lhs.g - rhs.g
        let db = lhs.b - rhs.b
        return dr * dr + dg * dg + db * db
    }

    private struct OKLab {
        let l: Double
        let a: Double
        let b: Double
    }

    private static func okLab(_ rgb: MixboxEngine.RGB) -> OKLab {
        let r = linearize(rgb.r)
        let g = linearize(rgb.g)
        let b = linearize(rgb.b)

        let l = 0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b
        let m = 0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b
        let s = 0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b
        let lRoot = cbrt(l)
        let mRoot = cbrt(m)
        let sRoot = cbrt(s)

        return OKLab(
            l: 0.2104542553 * lRoot + 0.7936177850 * mRoot - 0.0040720468 * sRoot,
            a: 1.9779984951 * lRoot - 2.4285922050 * mRoot + 0.4505937099 * sRoot,
            b: 0.0259040371 * lRoot + 0.7827717662 * mRoot - 0.8086757660 * sRoot
        )
    }

    private static func linearize(_ value: Double) -> Double {
        value <= 0.04045
            ? value / 12.92
            : pow((value + 0.055) / 1.055, 2.4)
    }
}

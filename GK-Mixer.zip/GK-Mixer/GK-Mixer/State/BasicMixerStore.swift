import Foundation
import Observation

@MainActor
@Observable
final class BasicMixerStore {
    var paintAmounts: [Double] = Array(
        repeating: 0,
        count: MixboxRecipeSnapshot.gaiaProcessPigments.count
    )

    private(set) var result: BasicMixResult?
    private(set) var ralMatch: RALMatchSnapshot?
    private(set) var errorMessage: String?
    private(set) var isMixing = false

    var totalParts: Double {
        paintAmounts.reduce(0) { $0 + max(0, $1) }
    }

    var resultName: String {
        ralMatch?.displayName ?? String(localized: "基础调色")
    }

    func recalculate() async {
        let currentAmounts = paintAmounts
        guard currentAmounts.contains(where: { $0 > 0.001 }) else {
            result = nil
            ralMatch = nil
            errorMessage = nil
            return
        }

        isMixing = true
        errorMessage = nil
        defer {
            if currentAmounts == paintAmounts {
                isMixing = false
            }
        }

        do {
            let mixed = try await ColorAlgorithmRuntime.shared.mixBasic(weights: currentAmounts)
            guard currentAmounts == paintAmounts else { return }
            result = mixed
            if let hex = mixed?.hex {
                ralMatch = try await ColorAlgorithmRuntime.shared.nearestRAL(hex: hex)
            } else {
                ralMatch = nil
            }
        } catch {
            guard currentAmounts == paintAmounts else { return }
            result = nil
            ralMatch = nil
            errorMessage = error.localizedDescription
        }
    }

    func reset() {
        paintAmounts = Array(repeating: 0, count: paintAmounts.count)
        result = nil
        ralMatch = nil
        errorMessage = nil
        isMixing = false
    }
}

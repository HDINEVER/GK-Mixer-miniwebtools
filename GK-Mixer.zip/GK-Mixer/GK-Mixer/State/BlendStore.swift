import Foundation
import Observation

enum BlendColorSource: String, Codable, Equatable {
    case extract
    case picker
    case cmy
    case blackWhite
}

struct BlendColorEntry: Identifiable, Equatable {
    let id: UUID
    var hex: String
    var name: String
    /// Relative parts, matching BasicMixer’s 0…100 scale.
    var amount: Double
    var source: BlendColorSource

    init(
        id: UUID = UUID(),
        hex: String,
        name: String = "",
        amount: Double = 0,
        source: BlendColorSource = .picker
    ) {
        self.id = id
        self.hex = HexColor.normalize(hex) ?? "#000000"
        self.name = name.trimmingCharacters(in: .whitespacesAndNewlines)
        self.amount = max(0, amount)
        self.source = source
    }

    var displayName: String {
        if name.isEmpty { return hex }
        return L10n.localizedPigmentName(name)
    }
}

enum BlendAddResult: Equatable {
    case added
    case duplicate
    case atCapacity
    case invalidHex
}

@MainActor
@Observable
final class BlendStore {
    static let maxColors = 19
    static let defaultVolume = 20

    var colors: [BlendColorEntry] = []
    var targetVolume = BlendStore.defaultVolume
    private(set) var resultHex: String?
    private(set) var ralMatch: RALMatchSnapshot?
    private(set) var errorMessage: String?
    private(set) var isMixing = false
    private(set) var cmyAdded = false
    private(set) var blackWhiteAdded = false
    /// One-shot banner after cross-tab add (consumed by BlendView).
    var bannerMessage: String?

    private let cmyHexes = ["#00B7EB", "#FF0090", "#FFEF00"]
    private let blackWhiteHexes = ["#FFFFFF", "#000000"]

    var totalParts: Double {
        colors.reduce(0) { $0 + max(0, $1.amount) }
    }

    var activeColors: [BlendColorEntry] {
        colors.filter { $0.amount > 0.001 }
    }

    var resultName: String {
        ralMatch?.displayName ?? String(localized: "自选混色")
    }

    @discardableResult
    func addColor(
        hex: String,
        name: String = "",
        source: BlendColorSource = .picker,
        amount: Double = 0
    ) -> BlendAddResult {
        guard let normalized = HexColor.normalize(hex) else {
            return .invalidHex
        }
        if colors.contains(where: { $0.hex == normalized }) {
            return .duplicate
        }
        if colors.count >= Self.maxColors {
            return .atCapacity
        }

        colors.insert(
            BlendColorEntry(
                hex: normalized,
                name: name,
                amount: amount,
                source: source
            ),
            at: 0
        )
        return .added
    }

    /// Web “+ 添加 CMY 三原色”.
    func addCMYPrimaries() {
        guard !cmyAdded else { return }
        // Persist Chinese catalog keys; localize at display time.
        let names = ["色源青", "色源品红", "色源黄"]
        for (hex, name) in zip(cmyHexes, names) {
            _ = addColor(hex: hex, name: name, source: .cmy)
        }
        cmyAdded = true
    }

    /// Web “+ 添加黑白色”.
    func addBlackAndWhite() {
        guard !blackWhiteAdded else { return }
        let names = ["白", "黑"]
        for (hex, name) in zip(blackWhiteHexes, names) {
            _ = addColor(hex: hex, name: name, source: .blackWhite)
        }
        blackWhiteAdded = true
    }

    func removeColor(id: UUID) {
        guard let index = colors.firstIndex(where: { $0.id == id }) else { return }
        let removed = colors.remove(at: index)
        if removed.source == .cmy {
            cmyAdded = colors.contains { $0.source == .cmy }
        }
        if removed.source == .blackWhite {
            blackWhiteAdded = colors.contains { $0.source == .blackWhite }
        }
    }

    func clear() {
        colors = []
        resultHex = nil
        ralMatch = nil
        errorMessage = nil
        isMixing = false
        cmyAdded = false
        blackWhiteAdded = false
        targetVolume = Self.defaultVolume
    }

    func consumeBanner() -> String? {
        defer { bannerMessage = nil }
        return bannerMessage
    }

    func recalculate() async {
        let snapshot = colors
        let active = snapshot
            .filter { $0.amount > 0.001 }
            .map { (hex: $0.hex, weight: $0.amount) }

        guard !active.isEmpty else {
            resultHex = nil
            ralMatch = nil
            errorMessage = nil
            return
        }

        isMixing = true
        errorMessage = nil
        defer {
            if snapshot == colors {
                isMixing = false
            }
        }

        do {
            let mixed = try await ColorAlgorithmRuntime.shared.mixMulti(colors: active)
            guard snapshot == colors else { return }
            resultHex = mixed?.hex
            if let hex = mixed?.hex {
                ralMatch = try await ColorAlgorithmRuntime.shared.nearestRAL(hex: hex)
            } else {
                ralMatch = nil
            }
        } catch {
            guard snapshot == colors else { return }
            resultHex = nil
            ralMatch = nil
            errorMessage = error.localizedDescription
        }
    }
}

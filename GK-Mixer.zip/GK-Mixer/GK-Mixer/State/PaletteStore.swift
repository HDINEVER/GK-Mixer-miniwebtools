import Foundation
import Observation
import SwiftData

@MainActor
@Observable
final class PaletteStore {
    enum SaveResult: Equatable {
        case inserted
        case updatedExisting
        case invalidHex
        case failed(String)
    }

    private let context: ModelContext

    private(set) var colors: [SavedColor] = []
    private(set) var categories: [PaletteCategory] = []
    private(set) var lastError: String?

    init(modelContext: ModelContext) {
        context = modelContext
        refresh()
    }

    func refresh() {
        do {
            colors = try context.fetch(
                FetchDescriptor<SavedColor>(
                    sortBy: [SortDescriptor(\.updatedAt, order: .reverse)]
                )
            )
            categories = try context.fetch(
                FetchDescriptor<PaletteCategory>(
                    sortBy: [
                        SortDescriptor(\.sortOrder),
                        SortDescriptor(\.name),
                    ]
                )
            )
            lastError = nil
        } catch {
            lastError = error.localizedDescription
        }
    }

    @discardableResult
    func saveFromMixer(
        hex: String,
        name: String,
        recipe: MixboxRecipeSnapshot,
        ralMatch: RALMatchSnapshot? = nil
    ) -> SaveResult {
        guard let normalizedHex = HexColor.normalize(hex) else {
            return .invalidHex
        }

        if let existing = colors.first(where: { $0.normalizedHex == normalizedHex }) {
            existing.recipe = recipe
            existing.ralMatch = ralMatch
            if existing.name == L10n.untitledColorSentinel,
               name != L10n.untitledColorSentinel,
               name != L10n.untitledColor {
                existing.name = name
            }
            return persist(.updatedExisting)
        }

        context.insert(
            SavedColor(
                hex: normalizedHex,
                name: name.isEmpty || name == L10n.untitledColor
                    ? L10n.untitledColorSentinel
                    : name,
                recipe: recipe,
                ralMatch: ralMatch
            )
        )
        return persist(.inserted)
    }

    func rename(_ color: SavedColor, to name: String) {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        color.name = trimmed.isEmpty || trimmed == L10n.untitledColor
            ? L10n.untitledColorSentinel
            : trimmed
        color.updatedAt = .now
        _ = saveChanges()
    }

    func assign(_ color: SavedColor, to category: PaletteCategory?) {
        color.category = category
        color.updatedAt = .now
        _ = saveChanges()
    }

    @discardableResult
    func createCategory(named name: String) -> PaletteCategory? {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return nil }

        let key = PaletteCategory.normalize(trimmed)
        if let existing = categories.first(where: { $0.normalizedName == key }) {
            return existing
        }

        let category = PaletteCategory(
            name: trimmed,
            sortOrder: (categories.map(\.sortOrder).max() ?? -1) + 1
        )
        context.insert(category)
        return saveChanges() ? category : nil
    }

    func renameCategory(_ category: PaletteCategory, to name: String) -> Bool {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        let key = PaletteCategory.normalize(trimmed)
        guard !trimmed.isEmpty,
              !categories.contains(where: {
                  $0.id != category.id && $0.normalizedName == key
              }) else {
            return false
        }

        category.name = trimmed
        category.normalizedName = key
        return saveChanges()
    }

    func deleteCategory(_ category: PaletteCategory) {
        for color in colors where color.category?.id == category.id {
            color.category = nil
            color.updatedAt = .now
        }
        context.delete(category)
        _ = saveChanges()
    }

    func delete(_ color: SavedColor) {
        context.delete(color)
        _ = saveChanges()
    }

    func count(in category: PaletteCategory?) -> Int {
        guard let category else { return colors.count }
        return colors.lazy.filter { $0.category?.id == category.id }.count
    }

    func filtered(searchText: String, categoryID: UUID?) -> [SavedColor] {
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        return colors.filter { color in
            let isInCategory = categoryID == nil || color.category?.id == categoryID
            let matchesSearch = query.isEmpty
                || color.normalizedHex.localizedCaseInsensitiveContains(query)
                || color.name.localizedCaseInsensitiveContains(query)
            return isInCategory && matchesSearch
        }
    }

    private func saveChanges() -> Bool {
        do {
            try context.save()
            refresh()
            return true
        } catch {
            lastError = error.localizedDescription
            return false
        }
    }

    private func persist(_ success: SaveResult) -> SaveResult {
        do {
            try context.save()
            refresh()
            return success
        } catch {
            lastError = error.localizedDescription
            return .failed(error.localizedDescription)
        }
    }
}

import Observation
import SwiftUI
import UIKit

@MainActor
@Observable
final class WorkbenchStore {
    enum Segment: String, CaseIterable, Identifiable {
        case extract
        case mixer

        var id: Self { self }

        var title: String {
            switch self {
            case .extract: String(localized: "拾色")
            case .mixer: String(localized: "混色")
            }
        }
    }

    var segment: Segment = .extract
    var targetColor = Color(hex: "#FF9900")
    private(set) var resultHex = "#FF9900"
    private(set) var resultName = L10n.untitledColorSentinel
    private(set) var recipe: MixboxRecipeSnapshot?
    private(set) var ralMatch: RALMatchSnapshot?
    private(set) var analysisError: String?
    private(set) var isAnalyzing = false

    /// Set by Palette detail's “添加到配方”. It deliberately does not switch
    /// tabs; the recipe is ready the next time the user opens the workbench.
    private(set) var pendingRecipe: MixboxRecipeSnapshot?
    private(set) var pendingHex: String?
    private(set) var pendingRALMatch: RALMatchSnapshot?

    func updateTargetColor(_ color: Color) {
        targetColor = color
        guard let hex = Self.hexString(from: color) else { return }
        resultHex = hex
        recipe = nil
        ralMatch = nil
        analysisError = nil
    }

    func solveCurrentRecipe() async {
        let targetHex = resultHex
        isAnalyzing = true
        analysisError = nil
        defer {
            if targetHex == resultHex {
                isAnalyzing = false
            }
        }

        do {
            async let recipe = ColorAlgorithmRuntime.shared.decompose(hex: targetHex)
            async let ralMatch = ColorAlgorithmRuntime.shared.nearestRAL(hex: targetHex)
            let (resolvedRecipe, resolvedRAL) = try await (recipe, ralMatch)
            guard targetHex == resultHex else { return }

            self.recipe = resolvedRecipe
            self.ralMatch = resolvedRAL
            if let resolvedRAL {
                resultName = resolvedRAL.displayName
            }
        } catch {
            guard targetHex == resultHex else { return }
            recipe = nil
            ralMatch = nil
            analysisError = error.localizedDescription
        }
    }

    func updateRecipe(_ value: MixboxRecipeSnapshot?) {
        recipe = value?.normalized()
    }

    func updateResultName(_ name: String) {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        resultName = trimmed.isEmpty ? L10n.untitledColorSentinel : trimmed
    }

    func stageRecipe(from color: SavedColor) {
        pendingRecipe = color.recipe
        pendingHex = color.normalizedHex
        pendingRALMatch = color.ralMatch
    }

    func loadPendingRecipe() {
        guard let pendingRecipe, let pendingHex else { return }
        segment = .mixer
        resultHex = pendingHex
        targetColor = Color(hex: pendingHex)
        recipe = pendingRecipe
        ralMatch = pendingRALMatch
        if let pendingRALMatch {
            resultName = pendingRALMatch.displayName
        }
        self.pendingRecipe = nil
        self.pendingHex = nil
        self.pendingRALMatch = nil
    }

    private static func hexString(from color: Color) -> String? {
        let resolved = UIColor(color)
        var red: CGFloat = 0
        var green: CGFloat = 0
        var blue: CGFloat = 0
        var alpha: CGFloat = 0
        guard resolved.getRed(&red, green: &green, blue: &blue, alpha: &alpha) else {
            return nil
        }

        return String(
            format: "#%02X%02X%02X",
            Int((red * 255).rounded()),
            Int((green * 255).rounded()),
            Int((blue * 255).rounded())
        )
    }
}

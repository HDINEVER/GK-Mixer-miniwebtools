import SwiftUI

struct BasicMixerView: View {
    @Environment(BasicMixerStore.self) private var store
    @Environment(PaletteStore.self) private var palette
    @AppStorage("basicMixVolume") private var targetVolume = 20
    @State private var notice: String?
    @State private var feedbackTrigger = 0

    private let volumes = [10, 20, 30, 40, 50, 60]

    private var activeRecipeRows: [(paint: BasicPaint, amount: Double, fraction: Double)] {
        let total = max(store.totalParts, 0.0001)
        return BasicPaint.all.enumerated().compactMap { index, paint in
            let amount = store.paintAmounts[index]
            guard amount > 0.001 else { return nil }
            return (paint, amount, amount / total)
        }
    }

    var body: some View {
        @Bindable var store = store

        ScrollView {
            VStack(spacing: Spacing.lg) {
                    // Result preview
                    VStack(spacing: Spacing.md) {
                        SectionHeader(title: "混合结果", icon: "flask.fill")

                        if let result = store.result {
                            RoundedRectangle(
                                cornerRadius: CornerRadius.well + 2,
                                style: .continuous
                            )
                            .fill(Color(hex: result.hex))
                            .frame(height: 100)
                            .overlay(alignment: .bottomLeading) {
                                CopyableHexChip(hex: result.hex)
                                    .padding(Spacing.xs)
                            }
                        } else {
                            PlaceholderWell(cornerRadius: CornerRadius.well + 2) {
                                VStack(spacing: Spacing.xxs + 2) {
                                    Image(systemName: "eyedropper")
                                        .font(.title2)
                                    Text(basicEmptyHint)
                                        .font(.caption)
                                }
                                .foregroundStyle(.tertiary)
                            }
                            .frame(height: 100)
                        }
                    }
                    .contentCard()

                    // Paint sliders
                    VStack(spacing: Spacing.md) {
                        SectionHeader(title: "基础颜料", icon: "drop.fill")

                        VStack(spacing: Spacing.sm) {
                            ForEach(Array(BasicPaint.all.enumerated()), id: \.element.id) { index, paint in
                                PaintSliderRow(paint: paint, amount: $store.paintAmounts[index])
                            }
                        }
                    }
                    .contentCard()

                    // RAL recognition — below basic pigments
                    ralCard

                    // Recipe output — same ml layout as BlendView
                    VStack(spacing: Spacing.md) {
                        SectionHeader(title: "配方输出", icon: "list.bullet.rectangle")

                        Picker("目标总量", selection: $targetVolume) {
                            ForEach(volumes, id: \.self) { volume in
                                Text("\(volume)ml").tag(volume)
                            }
                        }
                        .pickerStyle(.segmented)

                        LabeledContent("总量") {
                            Text("\(targetVolume)ml")
                                .monospaced()
                        }

                        if activeRecipeRows.isEmpty {
                            Text("所有滑块都在 0 时不会产生混合色。")
                                .font(.caption)
                                .foregroundStyle(.tertiary)
                                .frame(maxWidth: .infinity, alignment: .leading)
                        } else {
                            ForEach(activeRecipeRows, id: \.paint.id) { row in
                                HStack(spacing: Spacing.sm) {
                                    Circle()
                                        .fill(row.paint.color)
                                        .frame(width: 18, height: 18)
                                        .overlay(Circle().strokeBorder(.primary.opacity(0.15)))
                                    Text(L10n.localizedPigmentName(row.paint.name))
                                        .font(.caption)
                                        .lineLimit(1)
                                    Spacer(minLength: 0)
                                    Text(row.fraction, format: .percent.precision(.fractionLength(0)))
                                        .font(.caption2.monospaced())
                                        .foregroundStyle(.secondary)
                                    Text(
                                        (row.fraction * Double(targetVolume))
                                            .formatted(.number.precision(.fractionLength(1))) + "ml"
                                    )
                                    .font(.caption.monospaced().weight(.semibold))
                                }
                            }
                        }
                    }
                    .contentCard()

                    // Actions
                    HStack(spacing: Spacing.sm) {
                        ActionButton(
                            title: String(localized: "保存配方"),
                            icon: "square.and.arrow.down",
                            isProminent: true
                        ) {
                            saveResult()
                        }
                        .disabled(store.result == nil)
                        ActionButton(
                            title: String(localized: "重置"),
                            icon: "arrow.counterclockwise",
                            tint: AppColor.neutral
                        ) {
                            withAnimation { store.reset() }
                        }
                    }
            }
            .padding(.horizontal, Spacing.md)
            .padding(.bottom, Spacing.lg)
        }
        .background(AppColor.canvas)
        .task(id: store.paintAmounts) {
            try? await Task.sleep(for: .milliseconds(60))
            guard !Task.isCancelled else { return }
            await store.recalculate()
        }
        .alert(
            notice ?? "",
            isPresented: Binding(
                get: { notice != nil },
                set: { if !$0 { notice = nil } }
            )
        ) {
            Button("好", role: .cancel) {}
        }
        .sensoryFeedback(.success, trigger: feedbackTrigger)
    }

    private var basicEmptyHint: String {
        store.errorMessage ?? String(localized: "调整下方滑块开始混色")
    }

    private var basicRALEmptyHint: String {
        store.result == nil
            ? String(localized: "调整颜料后显示最近 RAL 色")
            : String(localized: "暂无 RAL 匹配结果")
    }

    private var ralCard: some View {
        VStack(spacing: Spacing.md) {
            SectionHeader(title: "RAL 色卡", icon: "square.grid.3x3.fill")

            if let ral = store.ralMatch {
                HStack(spacing: Spacing.sm) {
                    RoundedRectangle(cornerRadius: CornerRadius.swatch, style: .continuous)
                        .fill(Color(hex: ral.standardHex))
                        .frame(width: 64, height: 64)
                        .overlay(
                            RoundedRectangle(
                                cornerRadius: CornerRadius.swatch,
                                style: .continuous
                            )
                            .strokeBorder(.primary.opacity(0.12))
                        )

                    VStack(alignment: .leading, spacing: Spacing.xxs) {
                        Text(verbatim: "RAL \(ral.number) \(ral.name)")
                            .font(.headline)
                        Text("\(ral.standardHex) · LRV \(ral.lrv.formatted())")
                            .font(.caption.monospaced())
                            .foregroundStyle(.secondary)
                        Text("近似匹配，仅供参考，并非 RAL 官方认证。")
                            .font(.caption)
                            .foregroundStyle(.tertiary)
                    }
                    Spacer(minLength: 0)
                }
            } else if store.isMixing {
                ProgressView("正在匹配 RAL…")
                    .frame(maxWidth: .infinity, alignment: .leading)
            } else {
                PlaceholderWell {
                    Text(basicRALEmptyHint)
                        .font(.caption)
                        .foregroundStyle(.tertiary)
                }
                .frame(height: 72)
            }
        }
        .contentCard()
    }

    private func saveResult() {
        guard let result = store.result else { return }
        switch palette.saveFromMixer(
            hex: result.hex,
            name: store.resultName,
            recipe: result.recipe,
            ralMatch: store.ralMatch
        ) {
        case .inserted:
            notice = String(localized: "已保存到调色板")
            feedbackTrigger += 1
        case .updatedExisting:
            notice = String(localized: "该 HEX 已存在，已刷新基础调色配方")
            feedbackTrigger += 1
        case .invalidHex:
            notice = String(localized: "颜色格式无效")
        case .failed(let message):
            notice = L10n.saveFailed(message)
        }
    }
}

// MARK: - Basic paint

struct BasicPaint: Identifiable {
    let id: String
    let name: String
    let color: Color

    /// Absolute pigment values — must match Web `BasicColorMixer` DEFAULT_BASE_COLORS
    /// (5 Gaia solids + 3 Process / 色源 CMY primaries). Never theme-adaptive.
    static let all: [BasicPaint] = [
        BasicPaint(id: "W", name: "白", color: Color(hex: "#FFFFFF")),
        BasicPaint(id: "K", name: "黑", color: Color(hex: "#000000")),
        BasicPaint(id: "R", name: "红", color: Color(hex: "#E60012")),
        BasicPaint(id: "B", name: "蓝", color: Color(hex: "#004098")),
        BasicPaint(id: "Y", name: "黄", color: Color(hex: "#FFD900")),
        BasicPaint(id: "SY", name: "色源黄", color: Color(hex: "#FFEF00")),
        BasicPaint(id: "SC", name: "色源青", color: Color(hex: "#00B7EB")),
        BasicPaint(id: "SM", name: "色源品红", color: Color(hex: "#FF0090")),
    ]
}

// MARK: - Paint Slider Row

private struct PaintSliderRow: View {
    let paint: BasicPaint
    @Binding var amount: Double

    var body: some View {
        HStack(spacing: Spacing.sm) {
            Circle()
                .fill(paint.color)
                .frame(width: 28, height: 28)
                // Keeps near-black and near-white pigments legible against either appearance.
                .overlay(Circle().strokeBorder(.primary.opacity(0.15), lineWidth: 1))

            Text(L10n.localizedPigmentName(paint.name))
                .font(.subheadline)
                .lineLimit(1)
                .minimumScaleFactor(0.75)
                .frame(width: 64, alignment: .leading)

            Slider(value: $amount, in: 0...100) {
                Text(L10n.localizedPigmentName(paint.name))
            }
            .tint(paint.color)

            Text(amount, format: .number.precision(.fractionLength(0)))
                .font(.caption2.monospaced())
                .foregroundStyle(.secondary)
                .frame(width: 32, alignment: .trailing)
        }
    }
}

#Preview {
    BasicMixerView()
}

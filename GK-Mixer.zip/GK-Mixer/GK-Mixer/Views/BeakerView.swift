import SwiftUI

/// SwiftUI reproduction of the web `MixerResult` bottle: a labelled cylinder
/// with tick marks and layered pigments stacked bottom-to-top by weight.
struct BeakerView: View {
    let recipe: MixboxRecipeSnapshot?
    let totalVolumeMl: Int

    private var layers: [BeakerLayer] {
        guard let recipe else { return [] }
        return BeakerLayer.layers(from: recipe)
    }

    var body: some View {
        HStack(alignment: .center, spacing: Spacing.md) {
            bottle
            legend
        }
        .frame(maxWidth: .infinity)
        .padding(Spacing.md)
        .background(
            RoundedRectangle(cornerRadius: CornerRadius.well, style: .continuous)
                .fill(AppColor.surfaceNested)
        )
    }

    // MARK: - Bottle

    private var bottle: some View {
        VStack(spacing: 0) {
            neck
            body(width: 96, height: 216)
        }
        .accessibilityElement()
        .accessibilityLabel(String(localized: "配方混色瓶"))
        .accessibilityValue(
            layers.isEmpty
                ? String(localized: "空瓶")
                : layers.map { "\($0.label) \(percentText(for: $0.percent))" }
                    .joined(separator: "，")
        )
    }

    private var neck: some View {
        UnevenRoundedRectangle(
            topLeadingRadius: 3,
            topTrailingRadius: 3
        )
        .fill(AppColor.surface)
        .overlay(
            UnevenRoundedRectangle(
                topLeadingRadius: 3,
                topTrailingRadius: 3
            )
            .strokeBorder(.primary.opacity(0.18), lineWidth: 1)
        )
        .frame(width: 48, height: 10)
    }

    private func body(width: CGFloat, height: CGFloat) -> some View {
        ZStack(alignment: .bottom) {
            RoundedRectangle(cornerRadius: 10, style: .continuous)
                .fill(AppColor.surface)

            VStack(spacing: 0) {
                ForEach(layers.reversed()) { layer in
                    Rectangle()
                        .fill(Color(hex: layer.hex))
                        .frame(height: max(1, height * layer.percent))
                        .overlay(
                            Text(layer.label)
                                .font(.caption2.monospaced().weight(.semibold))
                                .foregroundStyle(layer.readableTextColor)
                                .opacity(layer.percent > 0.06 ? 0.9 : 0)
                        )
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))

            ticks(height: height)

            // Left-edge specular reflection to match the web bottle's glossy feel.
            LinearGradient(
                colors: [.white.opacity(0.32), .white.opacity(0)],
                startPoint: .leading,
                endPoint: .trailing
            )
            .frame(width: 6)
            .padding(.vertical, 6)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.leading, 4)
            .allowsHitTesting(false)

            RoundedRectangle(cornerRadius: 10, style: .continuous)
                .strokeBorder(.primary.opacity(0.22), lineWidth: 1)
        }
        .frame(width: width, height: height)
    }

    private func ticks(height: CGFloat) -> some View {
        VStack(spacing: 0) {
            ForEach(0..<10) { index in
                HStack(spacing: 3) {
                    Spacer(minLength: 0)
                    Text("\((10 - index) * 10)%")
                        .font(.system(size: 8, weight: .medium, design: .monospaced))
                        .foregroundStyle(.tertiary)
                    Rectangle()
                        .fill(.primary.opacity(0.25))
                        .frame(width: 6, height: 1)
                }
                .frame(height: height / 10, alignment: .top)
            }
        }
        .padding(.trailing, 4)
        .allowsHitTesting(false)
    }

    // MARK: - Legend

    private var legend: some View {
        VStack(alignment: .leading, spacing: Spacing.xxs + 2) {
            HStack {
                Text("目标容量")
                    .font(.caption2.weight(.semibold))
                    .foregroundStyle(.secondary)
                Spacer()
                Text("\(totalVolumeMl)ml")
                    .font(.caption.monospaced().weight(.semibold))
            }
            .padding(.bottom, Spacing.xxs)

            if layers.isEmpty {
                Text("等待混色结果")
                    .font(.caption)
                    .foregroundStyle(.tertiary)
            } else {
                ForEach(layers) { layer in
                    HStack(spacing: Spacing.xs) {
                        Circle()
                            .fill(Color(hex: layer.hex))
                            .frame(width: 10, height: 10)
                            .overlay(
                                Circle()
                                    .strokeBorder(.primary.opacity(0.15), lineWidth: 1)
                            )
                        Text(layer.legendTitle)
                            .font(.caption2.monospaced())
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                        Spacer(minLength: 0)
                        Text("\((Double(totalVolumeMl) * layer.percent).formatted(.number.precision(.fractionLength(1))))ml")
                            .font(.caption2.monospaced().weight(.semibold))
                    }
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func percentText(for percent: Double) -> String {
        percent.formatted(.percent.precision(.fractionLength(0)))
    }
}

// MARK: - Layer model

private struct BeakerLayer: Identifiable {
    let id: String
    let hex: String
    let label: String
    let legendTitle: String
    let percent: Double
    let isBase: Bool

    var readableTextColor: Color {
        let upper = hex.uppercased()
        if upper == "#FFFFFF" || upper == "#FFEF00" || upper == "#FFD900" {
            return .black.opacity(0.75)
        }
        return .white.opacity(0.95)
    }

    static func layers(from recipe: MixboxRecipeSnapshot) -> [BeakerLayer] {
        // Match the web: skip pigments below 1% and re-normalise the remainder
        // so the bottle fill still totals 100%.
        let filtered = recipe.components.enumerated().filter { _, component in
            component.weight > 0.01
        }
        let visibleTotal = filtered.reduce(0) { $0 + $1.element.weight }
        guard visibleTotal > 0 else { return [] }

        return filtered.map { index, component in
            let code = pigmentCode(for: component)
            let isBase = isBaseLayer(
                component: component,
                index: index,
                paletteID: recipe.paletteID
            )
            return BeakerLayer(
                id: component.id,
                hex: component.hex,
                label: code,
                legendTitle: isBase ? L10n.baseCoat(code) : "+ \(code)",
                percent: component.weight / visibleTotal,
                isBase: isBase
            )
        }
    }

    private static func pigmentCode(for component: MixboxRecipeComponent) -> String {
        if let suffix = component.id.split(separator: "-").last,
           suffix.allSatisfy(\.isNumber) || suffix.count <= 3 {
            return String(suffix)
        }
        return component.name
    }

    private static func isBaseLayer(
        component: MixboxRecipeComponent,
        index: Int,
        paletteID: MixboxPaletteID
    ) -> Bool {
        switch paletteID {
        case .legacyExtended8:
            return index < 2
        case .gaiaProcess8:
            let upper = component.hex.uppercased()
            return upper == "#FFFFFF" || upper == "#000000"
        }
    }
}

#Preview {
    BeakerView(
        recipe: MixboxRecipeSnapshot(
            paletteID: .gaiaProcess8,
            components: MixboxRecipeSnapshot.gaiaProcessPigments.enumerated().map { index, pigment in
                MixboxRecipeComponent(
                    id: pigment.id,
                    name: pigment.name,
                    hex: pigment.hex,
                    weight: [0.30, 0.10, 0.25, 0.20, 0.15, 0, 0, 0][index]
                )
            }
        ),
        totalVolumeMl: 30
    )
    .padding()
}

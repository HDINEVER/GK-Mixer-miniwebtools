import SwiftUI
import UIKit

struct BlendView: View {
    @Environment(BlendStore.self) private var store
    @Environment(PaletteStore.self) private var palette
    @State private var pickerColor = Color.white
    @State private var notice: String?
    @State private var feedbackTrigger = 0

    private let volumes = [10, 20, 30, 40, 50, 60]

    var body: some View {
        @Bindable var store = store

        ScrollView {
            VStack(spacing: Spacing.lg) {
                resultCard
                paletteCard
                if !store.colors.isEmpty {
                    recipeCard
                }
                actions
            }
            .padding(.horizontal, Spacing.md)
            .padding(.bottom, Spacing.lg)
        }
        .background(AppColor.canvas)
        .task(id: store.colors) {
            try? await Task.sleep(for: .milliseconds(60))
            guard !Task.isCancelled else { return }
            await store.recalculate()
        }
        .onAppear {
            if let banner = store.consumeBanner() {
                notice = banner
            }
        }
        .onChange(of: store.bannerMessage) { _, message in
            if let message {
                notice = store.consumeBanner() ?? message
            }
        }
        .alert(
            notice ?? "",
            isPresented: Binding(
                get: { notice != nil },
                set: { if !$0 { notice = nil } }
            )
        ) {
            Button("好", role: .cancel) {}
        }
        .sensoryFeedback(.success, trigger: feedbackTrigger)
    }

    // MARK: - Result

    private var resultCard: some View {
        VStack(spacing: Spacing.md) {
            SectionHeader(title: "混合结果", icon: "flask.fill")

            if let hex = store.resultHex {
                RoundedRectangle(
                    cornerRadius: CornerRadius.well + 2,
                    style: .continuous
                )
                .fill(Color(hex: hex))
                .frame(height: 110)
                .overlay(alignment: .bottomLeading) {
                    CopyableHexChip(hex: hex)
                        .padding(Spacing.xs)
                }
            } else {
                PlaceholderWell(cornerRadius: CornerRadius.well + 2) {
                    VStack(spacing: Spacing.xxs + 2) {
                        Image(systemName: store.colors.isEmpty ? "paintpalette" : "slider.horizontal.3")
                            .font(.title2)
                        Text(blendEmptyHint)
                        .font(.caption)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, Spacing.sm)
                    }
                    .foregroundStyle(.tertiary)
                }
                .frame(height: 110)
            }

            if let ral = store.ralMatch {
                LabeledContent("RAL 近似色") {
                    VStack(alignment: .trailing, spacing: 2) {
                        Text(verbatim: "RAL \(ral.number) \(ral.name)")
                        Text("\(ral.standardHex) · LRV \(ral.lrv.formatted())")
                            .font(.caption.monospaced())
                            .foregroundStyle(.secondary)
                    }
                }
            }
        }
        .contentCard()
    }

    // MARK: - Palette

    private var paletteCard: some View {
        @Bindable var store = store

        return VStack(spacing: Spacing.md) {
            SectionHeader(title: "自选颜色", icon: "circle.grid.cross")

            HStack(spacing: Spacing.sm) {
                ColorPicker(
                    "拾色",
                    selection: $pickerColor,
                    supportsOpacity: false
                )
                Button("添加", systemImage: "plus") {
                    addFromPicker(pickerColor)
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.small)
                .disabled(store.colors.count >= BlendStore.maxColors)
            }

            HStack(spacing: Spacing.sm) {
                Button("CMY 三原色", systemImage: "plus") {
                    store.addCMYPrimaries()
                }
                .buttonStyle(.bordered)
                .controlSize(.small)
                .disabled(store.cmyAdded || store.colors.count >= BlendStore.maxColors)

                Button("黑白", systemImage: "plus") {
                    store.addBlackAndWhite()
                }
                .buttonStyle(.bordered)
                .controlSize(.small)
                .disabled(store.blackWhiteAdded || store.colors.count >= BlendStore.maxColors)

                Spacer(minLength: 0)
            }

            if store.colors.isEmpty {
                Text("已选颜色会出现在这里。可从混色台 RAL 色卡点「+」导入。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)
            } else {
                VStack(spacing: Spacing.sm) {
                    ForEach($store.colors) { $entry in
                        BlendColorSliderRow(entry: $entry) {
                            withAnimation {
                                store.removeColor(id: entry.id)
                            }
                        }
                    }
                }
            }

            Picker("目标总量", selection: $store.targetVolume) {
                ForEach(volumes, id: \.self) { volume in
                    Text("\(volume)ml").tag(volume)
                }
            }
            .pickerStyle(.segmented)
        }
        .contentCard()
    }

    // MARK: - Recipe

    private var recipeCard: some View {
        VStack(spacing: Spacing.md) {
            SectionHeader(title: "混合配方", icon: "list.bullet.rectangle")

            LabeledContent("总量") {
                Text("\(store.targetVolume)ml")
                    .monospaced()
            }

            if store.activeColors.isEmpty {
                Text("所有滑块都在 0 时不会产生混合色。")
                    .font(.caption)
                    .foregroundStyle(.tertiary)
                    .frame(maxWidth: .infinity, alignment: .leading)
            } else {
                ForEach(store.activeColors) { entry in
                    let fraction = entry.amount / max(store.totalParts, 0.0001)
                    HStack(spacing: Spacing.sm) {
                        Circle()
                            .fill(Color(hex: entry.hex))
                            .frame(width: 18, height: 18)
                            .overlay(Circle().strokeBorder(.primary.opacity(0.15)))
                        Text(entry.displayName)
                            .font(.caption)
                            .lineLimit(1)
                        Spacer(minLength: 0)
                        Text(fraction, format: .percent.precision(.fractionLength(0)))
                            .font(.caption2.monospaced())
                            .foregroundStyle(.secondary)
                        Text(
                            (fraction * Double(store.targetVolume))
                                .formatted(.number.precision(.fractionLength(1))) + "ml"
                        )
                        .font(.caption.monospaced().weight(.semibold))
                    }
                }
            }
        }
        .contentCard()
    }

    // MARK: - Actions

    private var actions: some View {
        HStack(spacing: Spacing.sm) {
            ActionButton(
                title: String(localized: "添加到调色板"),
                icon: "plus.square",
                isProminent: true
            ) {
                Task { await saveResult() }
            }
            .disabled(store.resultHex == nil)

            ActionButton(
                title: String(localized: "清空"),
                icon: "trash",
                tint: AppColor.destructive
            ) {
                withAnimation { store.clear() }
            }
            .disabled(store.colors.isEmpty)
        }
    }

    // MARK: - Helpers

    private var blendEmptyHint: String {
        if let errorMessage = store.errorMessage {
            return errorMessage
        }
        return store.colors.isEmpty
            ? String(localized: "从混色台 RAL 色卡添加颜色，或使用下方拾色器")
            : String(localized: "拖动滑块设置各色用量开始混色")
    }

    private func addFromPicker(_ color: Color) {
        let resolved = UIColor(color)
        var r: CGFloat = 0
        var g: CGFloat = 0
        var b: CGFloat = 0
        var a: CGFloat = 0
        guard resolved.getRed(&r, green: &g, blue: &b, alpha: &a) else { return }
        let hex = String(
            format: "#%02X%02X%02X",
            Int((r * 255).rounded()),
            Int((g * 255).rounded()),
            Int((b * 255).rounded())
        )
        switch store.addColor(hex: hex, source: .picker) {
        case .added:
            feedbackTrigger += 1
        case .duplicate:
            notice = String(localized: "该颜色已在自选列表中")
        case .atCapacity:
            notice = L10n.maxColors(BlendStore.maxColors)
        case .invalidHex:
            notice = String(localized: "颜色格式无效")
        }
    }

    private func saveResult() async {
        guard let hex = store.resultHex else { return }
        do {
            let recipe = try await ColorAlgorithmRuntime.shared.decompose(hex: hex)
            switch palette.saveFromMixer(
                hex: hex,
                name: store.resultName,
                recipe: recipe,
                ralMatch: store.ralMatch
            ) {
            case .inserted:
                notice = String(localized: "已保存到调色板")
                feedbackTrigger += 1
            case .updatedExisting:
                notice = String(localized: "该 HEX 已存在，已刷新 Mixbox 分解")
                feedbackTrigger += 1
            case .invalidHex:
                notice = String(localized: "颜色格式无效")
            case .failed(let message):
                notice = L10n.saveFailed(message)
            }
        } catch {
            notice = L10n.saveFailed(error.localizedDescription)
        }
    }
}

// MARK: - Slider row

private struct BlendColorSliderRow: View {
    @Binding var entry: BlendColorEntry
    var onRemove: () -> Void

    var body: some View {
        HStack(spacing: Spacing.sm) {
            Circle()
                .fill(Color(hex: entry.hex))
                .frame(width: 28, height: 28)
                .overlay(Circle().strokeBorder(.primary.opacity(0.15), lineWidth: 1))

            VStack(alignment: .leading, spacing: 2) {
                Text(entry.displayName)
                    .font(.subheadline)
                    .lineLimit(1)
                    .minimumScaleFactor(0.75)
                Text(entry.hex)
                    .font(.caption2.monospaced())
                    .foregroundStyle(.secondary)
            }
            .frame(width: 78, alignment: .leading)

            Slider(value: $entry.amount, in: 0...100) {
                Text(entry.displayName)
            }
            .tint(Color(hex: entry.hex))

            Text(entry.amount, format: .number.precision(.fractionLength(0)))
                .font(.caption2.monospaced())
                .foregroundStyle(.secondary)
                .frame(width: 28, alignment: .trailing)

            Button(role: .destructive, action: onRemove) {
                Image(systemName: "minus.circle.fill")
            }
            .buttonStyle(.plain)
            .accessibilityLabel(L10n.removeColor(entry.displayName))
        }
    }
}

#Preview {
    BlendView()
        .environment(BlendStore())
}

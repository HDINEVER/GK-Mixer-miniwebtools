import SwiftUI

struct ExtractView: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: Spacing.lg) {
                    // Source image
                    VStack(spacing: Spacing.md) {
                        SectionHeader(title: "源图像", icon: "photo")

                        PlaceholderWell {
                            VStack(spacing: Spacing.xs) {
                                Image(systemName: "photo.on.rectangle.angled")
                                    .font(.largeTitle)
                                    .fontWeight(.light)
                                Text("点击导入图片")
                                    .font(.subheadline)
                            }
                            .foregroundStyle(.secondary)
                        }
                        .frame(height: 148)
                    }
                    .contentCard()

                    // Detected palette
                    VStack(spacing: Spacing.md) {
                        SectionHeader(title: "检测到的色板", icon: "swatchpalette")

                        HStack(spacing: Spacing.xs + 2) {
                            ForEach(0..<5, id: \.self) { _ in
                                PlaceholderWell(cornerRadius: CornerRadius.swatch) {
                                    Image(systemName: "plus")
                                        .font(.subheadline)
                                        .foregroundStyle(.tertiary)
                                }
                                .frame(width: 52, height: 60)
                            }
                            Spacer(minLength: 0)
                        }
                    }
                    .contentCard()

                    // CMYK analysis
                    VStack(spacing: Spacing.md) {
                        SectionHeader(title: "CMYK 分析", icon: "chart.bar")

                        VStack(spacing: Spacing.xs + 2) {
                            CMYKBar(label: "C", value: 0, color: .cyan)
                            CMYKBar(label: "M", value: 0, color: .pink)
                            CMYKBar(label: "Y", value: 0, color: .yellow)
                            CMYKBar(label: "K", value: 0, color: .primary)
                        }
                    }
                    .contentCard()

                    // RAL match
                    EmptyStateCard(
                        emoji: "🎯",
                        title: "RAL 色卡匹配",
                        subtitle: "导入图片并选取色块后\n将自动识别最接近的 RAL 标准色"
                    )
                    .contentCard()
                }
                .padding(.horizontal, Spacing.md)
                .padding(.bottom, Spacing.lg)
            }
            .background(AppColor.canvas)
            .navigationTitle("拾色")
        }
    }
}

// MARK: - CMYK Bar

private struct CMYKBar: View {
    let label: String
    let value: Double
    let color: Color

    var body: some View {
        HStack(spacing: Spacing.xs + 2) {
            Text(label)
                .font(.caption.weight(.bold).monospaced())
                .foregroundStyle(.secondary)
                .frame(width: Spacing.lg, alignment: .leading)

            ProgressView(value: value)
                .progressViewStyle(.linear)
                .tint(color)

            Text(value.formatted(.percent.precision(.fractionLength(0))))
                .font(.caption2.monospaced())
                .foregroundStyle(.tertiary)
                .frame(width: 36, alignment: .trailing)
        }
    }
}

#Preview {
    ExtractView()
}

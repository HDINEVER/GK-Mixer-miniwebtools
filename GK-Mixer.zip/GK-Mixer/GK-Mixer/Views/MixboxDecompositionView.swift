import SwiftUI

struct MixboxDecompositionView: View {
    let recipe: MixboxRecipeSnapshot?
    /// When set, trailing values are milliliters for the selected bottle volume.
    var totalVolumeMl: Double? = nil

    private var visibleComponents: [IndexedComponent] {
        guard let recipe else { return [] }
        return recipe.components.enumerated().compactMap { index, component in
            // Match web MixerResult: only show pigments above ~1%.
            guard component.weight > 0.01 else { return nil }
            return IndexedComponent(index: index, component: component)
        }
    }

    var body: some View {
        if let recipe, !visibleComponents.isEmpty {
            VStack(spacing: Spacing.sm) {
                ForEach(visibleComponents) { item in
                    row(for: item.component, index: item.index, recipe: recipe)
                }
            }
        } else if recipe != nil {
            ContentUnavailableView(
                "暂无有效颜料分量",
                systemImage: "chart.bar.xaxis",
                description: Text("当前颜色几乎是纯灰，或分量过低")
            )
        } else {
            ContentUnavailableView(
                "暂无 Mixbox 分解",
                systemImage: "chart.bar.xaxis",
                description: Text("完成一次 Mixbox 混色后会显示八种基础颜料比例")
            )
        }
    }

    private func row(
        for component: MixboxRecipeComponent,
        index: Int,
        recipe: MixboxRecipeSnapshot
    ) -> some View {
        HStack(spacing: Spacing.sm) {
            Circle()
                .fill(Color(hex: component.hex))
                .frame(width: 18, height: 18)
                .overlay(
                    Circle()
                        .strokeBorder(.primary.opacity(0.15), lineWidth: 1)
                )

            if let totalVolumeMl {
                Text(recipeLabel(for: component, index: index, paletteID: recipe.paletteID))
                    .font(.caption.monospaced())
                    .foregroundStyle(.secondary)
                Spacer(minLength: 0)
                Text(
                    "\((component.weight * totalVolumeMl).formatted(.number.precision(.fractionLength(1))))ml"
                )
                .font(.caption.monospaced().weight(.semibold))
            } else {
                Text(L10n.localizedPigmentName(component.name))
                    .font(.caption)
                    .frame(width: 58, alignment: .leading)

                ProgressView(value: component.weight, total: 1)
                    .tint(Color(hex: component.hex))

                Text(component.weight, format: .percent.precision(.fractionLength(0)))
                    .font(.caption2.monospaced())
                    .foregroundStyle(.secondary)
                    .frame(width: 38, alignment: .trailing)
            }
        }
        .accessibilityElement(children: .combine)
        .accessibilityLabel(recipeLabel(for: component, index: index, paletteID: recipe.paletteID))
        .accessibilityValue(accessibilityValue(for: component))
    }

    private func accessibilityValue(for component: MixboxRecipeComponent) -> String {
        if let totalVolumeMl {
            let ml = (component.weight * totalVolumeMl)
                .formatted(.number.precision(.fractionLength(1)))
            return L10n.milliliters(ml)
        }
        return component.weight.formatted(.percent.precision(.fractionLength(0)))
    }

    /// Web MixerResult labels: white/black as “底漆: code”, chromatic as “+ code”.
    private func recipeLabel(
        for component: MixboxRecipeComponent,
        index: Int,
        paletteID: MixboxPaletteID
    ) -> String {
        let code = pigmentCode(for: component)
        let isBaseLayer: Bool
        switch paletteID {
        case .legacyExtended8:
            isBaseLayer = index < 2
        case .gaiaProcess8:
            isBaseLayer = component.hex.uppercased() == "#FFFFFF"
                || component.hex.uppercased() == "#000000"
        }
        return isBaseLayer ? L10n.baseCoat(code) : "+ \(code)"
    }

    private func pigmentCode(for component: MixboxRecipeComponent) -> String {
        if let suffix = component.id.split(separator: "-").last,
           suffix.allSatisfy(\.isNumber) || suffix.count <= 3 {
            return String(suffix)
        }
        return component.name
    }
}

private struct IndexedComponent: Identifiable {
    var id: String { component.id }
    let index: Int
    let component: MixboxRecipeComponent
}

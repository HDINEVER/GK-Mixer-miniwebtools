import SwiftUI

struct MixerView: View {
    @AppStorage("mixVolume") private var selectedVolume = 30
    @AppStorage("mixAlgorithm") private var algorithm: MixAlgorithm = .mixbox

    private let volumes = [10, 20, 30, 40, 50, 60]

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: Spacing.lg) {
                    // Beaker
                    VStack(spacing: Spacing.md) {
                        SectionHeader(title: "混色烧杯", icon: "flask.fill")

                        PlaceholderWell {
                            VStack(spacing: Spacing.xxs + 2) {
                                Image(systemName: "flask")
                                    .font(.system(size: 36))
                                    .fontWeight(.light)
                                Text("添加颜料")
                                    .font(.caption2)
                            }
                            .foregroundStyle(.secondary)
                        }
                        .frame(width: 120, height: 160)

                        Picker("容量", selection: $selectedVolume) {
                            ForEach(volumes, id: \.self) { volume in
                                Text("\(volume)ml").tag(volume)
                            }
                        }
                        .pickerStyle(.segmented)
                        .labelsHidden()
                    }
                    .contentCard(padding: Spacing.lg)

                    // Algorithm
                    VStack(spacing: Spacing.md) {
                        SectionHeader(title: "混色算法", icon: "cpu")

                        Picker("混色算法", selection: $algorithm) {
                            ForEach(MixAlgorithm.allCases) { option in
                                Text(option.label).tag(option)
                            }
                        }
                        .pickerStyle(.segmented)
                        .labelsHidden()
                    }
                    .contentCard()

                    // RAL match
                    VStack(spacing: Spacing.md) {
                        SectionHeader(title: "RAL 标准色匹配", icon: "target")

                        EmptyStateCard(
                            emoji: "🎨",
                            title: "等待颜色输入",
                            subtitle: "添加颜料到烧杯后\n将自动匹配最接近的 RAL 标准色"
                        )
                    }
                    .contentCard()
                }
                .padding(.horizontal, Spacing.md)
                .padding(.bottom, Spacing.lg)
            }
            .background(AppColor.canvas)
            .navigationTitle("混色")
        }
    }
}

enum MixAlgorithm: String, CaseIterable, Identifiable {
    case professional = "Professional"
    case mixbox = "Mixbox"

    var id: Self { self }
    var label: String { rawValue }
}

#Preview {
    MixerView()
}

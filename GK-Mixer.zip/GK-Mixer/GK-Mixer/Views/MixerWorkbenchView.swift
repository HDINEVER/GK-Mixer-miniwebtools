import PhotosUI
import SwiftUI

struct MixerWorkbenchView: View {
    @Environment(WorkbenchStore.self) private var workbench

    var body: some View {
        @Bindable var workbench = workbench

        NavigationStack {
            VStack(spacing: 0) {
                Picker("混色台功能", selection: $workbench.segment) {
                    ForEach(WorkbenchStore.Segment.allCases) { segment in
                        Text(segment.title).tag(segment)
                    }
                }
                .pickerStyle(.segmented)
                .padding(.horizontal, Spacing.md)
                .padding(.bottom, Spacing.md)

                Group {
                    switch workbench.segment {
                    case .extract:
                        ExtractWorkbenchPanel()
                    case .mixer:
                        MixerWorkbenchPanel()
                    }
                }
            }
            .background(AppColor.canvas)
            .navigationTitle("混色台")
            .compactSettingsAccess()
            .task(id: workbench.resultHex) {
                try? await Task.sleep(for: .milliseconds(180))
                guard !Task.isCancelled else { return }
                await workbench.solveCurrentRecipe()
            }
        }
    }
}

// MARK: - Extract segment

private struct ExtractWorkbenchPanel: View {
    @Environment(WorkbenchStore.self) private var workbench
    @State private var photoItem: PhotosPickerItem?
    @State private var image: Image?

    var body: some View {
        ScrollView {
            VStack(spacing: Spacing.lg) {
                sourceImageCard
                RALColorCard(showsImageHint: image != nil)
            }
            .padding(.horizontal, Spacing.md)
            .padding(.bottom, Spacing.lg)
        }
        .task(id: photoItem) {
            guard let data = try? await photoItem?.loadTransferable(type: Data.self),
                  let uiImage = UIImage(data: data) else {
                return
            }
            image = Image(uiImage: uiImage)
        }
    }

    private var sourceImageCard: some View {
        VStack(spacing: Spacing.md) {
            SectionHeader(title: "源图像", icon: "photo")

            PhotosPicker(selection: $photoItem, matching: .images) {
                Group {
                    if let image {
                        image
                            .resizable()
                            .scaledToFit()
                            .frame(maxWidth: .infinity, maxHeight: 320)
                            .clipShape(
                                RoundedRectangle(
                                    cornerRadius: CornerRadius.well,
                                    style: .continuous
                                )
                            )
                    } else {
                        PlaceholderWell {
                            VStack(spacing: Spacing.xs) {
                                Image(systemName: "photo.on.rectangle.angled")
                                    .font(.largeTitle)
                                    .fontWeight(.light)
                                Text("从照片中选择")
                                    .font(.subheadline)
                            }
                            .foregroundStyle(.secondary)
                        }
                        .frame(height: 180)
                    }
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            if image != nil {
                ColorPicker(
                    "原生拾色器",
                    selection: Binding(
                        get: { workbench.targetColor },
                        set: { workbench.updateTargetColor($0) }
                    ),
                    supportsOpacity: false
                )

                Text("系统取色器可取样当前屏幕内容，包括上方图片。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
        .contentCard()
    }
}

// MARK: - Mixer segment

private struct MixerWorkbenchPanel: View {
    @Environment(PaletteStore.self) private var palette
    @Environment(WorkbenchStore.self) private var workbench
    @AppStorage("mixVolume") private var selectedVolume = 30
    @State private var notice: String?
    @State private var feedbackTrigger = 0

    private let volumes = [10, 20, 30, 40, 50, 60]

    var body: some View {
        ScrollView {
            VStack(spacing: Spacing.lg) {
                volumeCard
                beakerCard
                recipeVolumeCard
            }
            .padding(.horizontal, Spacing.md)
            .padding(.bottom, Spacing.lg)
        }
        .safeAreaInset(edge: .bottom) {
            saveButton
        }
        .alert(
            notice ?? "",
            isPresented: Binding(
                get: { notice != nil },
                set: { if !$0 { notice = nil } }
            )
        ) {
            Button("好", role: .cancel) {}
        }
        .sensoryFeedback(.success, trigger: feedbackTrigger)
        .onAppear {
            workbench.loadPendingRecipe()
        }
    }

    private var volumeCard: some View {
        VStack(spacing: Spacing.md) {
            SectionHeader(title: "目标容量", icon: "cylinder.split.1x2")

            Picker("容量", selection: $selectedVolume) {
                ForEach(volumes, id: \.self) { volume in
                    Text("\(volume)ml").tag(volume)
                }
            }
            .pickerStyle(.segmented)

            Text("按 Mixbox 八色分解换算各颜料毫升用量。")
                .font(.caption)
                .foregroundStyle(.secondary)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        .contentCard()
    }

    private var beakerCard: some View {
        VStack(spacing: Spacing.sm) {
            SectionHeader(title: "混色瓶预览", icon: "flask.fill")
            if workbench.isAnalyzing {
                ProgressView()
                    .frame(maxWidth: .infinity, minHeight: 120)
            } else {
                BeakerView(
                    recipe: workbench.recipe,
                    totalVolumeMl: selectedVolume
                )
            }
            Text("按照 Mixbox 分解比例分层填充，底部为底漆。")
                .font(.caption2)
                .foregroundStyle(.secondary)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        .contentCard()
    }

    private var recipeVolumeCard: some View {
        VStack(spacing: Spacing.md) {
            SectionHeader(title: "配方用量", icon: "drop.fill")
            if workbench.isAnalyzing {
                ProgressView("正在计算 Mixbox 毫升配方…")
                    .frame(maxWidth: .infinity, minHeight: 80)
            } else {
                MixboxDecompositionView(
                    recipe: workbench.recipe,
                    totalVolumeMl: Double(selectedVolume)
                )
            }
        }
        .contentCard()
    }

    private var saveButton: some View {
        Button("保存到调色板", systemImage: "square.and.arrow.down") {
            guard let recipe = workbench.recipe else { return }
            switch palette.saveFromMixer(
                hex: workbench.resultHex,
                name: workbench.resultName,
                recipe: recipe,
                ralMatch: workbench.ralMatch
            ) {
            case .inserted:
                notice = String(localized: "已保存到调色板")
                feedbackTrigger += 1
            case .updatedExisting:
                notice = String(localized: "该 HEX 已存在，已刷新 Mixbox 分解")
                feedbackTrigger += 1
            case .invalidHex:
                notice = String(localized: "颜色格式无效")
            case .failed(let message):
                notice = L10n.saveFailed(message)
            }
        }
        .buttonStyle(.glassProminent)
        .controlSize(.large)
        .disabled(workbench.recipe == nil)
        .padding(.horizontal, Spacing.md)
        .padding(.vertical, Spacing.xs)
    }
}

// MARK: - Shared RAL card

private struct RALColorCard: View {
    @Environment(WorkbenchStore.self) private var workbench
    @Environment(BlendStore.self) private var blendStore
    @AppStorage("selectedTabID") private var selectedTabID = AppTab.workbench.rawValue
    @AppStorage("tuningWorkbenchSegment") private var tuningSegment = "custom"
    @State private var addFeedback = 0
    @State private var addNotice: String?
    var showsImageHint = false

    var body: some View {
        VStack(spacing: Spacing.md) {
            SectionHeader(title: "RAL 色卡", icon: "square.grid.3x3.fill")

            RoundedRectangle(cornerRadius: CornerRadius.well, style: .continuous)
                .fill(Color(hex: workbench.resultHex))
                .frame(height: 150)
                .overlay(alignment: .topTrailing) {
                    Button {
                        addCurrentColorToBlend()
                    } label: {
                        Image(systemName: "plus")
                            .font(.body.weight(.semibold))
                            .frame(width: Spacing.touch, height: Spacing.touch)
                    }
                    .buttonStyle(.glass)
                    .buttonBorderShape(.circle)
                    .tint(.secondary)
                    .accessibilityLabel(String(localized: "添加到自选调色"))
                    .padding(Spacing.sm)
                }
                .overlay(alignment: .bottomLeading) {
                    CopyableHexChip(hex: workbench.resultHex)
                        .padding(Spacing.sm)
                }
                .sensoryFeedback(.success, trigger: addFeedback)

            ColorPicker(
                showsImageHint ? "原生拾色器" : "目标颜色",
                selection: Binding(
                    get: { workbench.targetColor },
                    set: { color in
                        workbench.updateTargetColor(color)
                    }
                ),
                supportsOpacity: false
            )

            LabeledContent("颜色名称") {
                Text(
                    workbench.resultName == L10n.untitledColorSentinel
                        ? L10n.untitledColor
                        : workbench.resultName
                )
                .foregroundStyle(.secondary)
            }

            if let ral = workbench.ralMatch {
                Divider()
                LabeledContent("RAL 近似色") {
                    HStack(spacing: Spacing.xs) {
                        Circle()
                            .fill(Color(hex: ral.standardHex))
                            .frame(width: 24, height: 24)
                            .overlay(Circle().strokeBorder(.primary.opacity(0.12)))
                        VStack(alignment: .trailing, spacing: 2) {
                            Text(verbatim: "RAL \(ral.number) \(ral.name)")
                            Text("\(ral.standardHex) · LRV \(ral.lrv.formatted())")
                                .font(.caption.monospaced())
                                .foregroundStyle(.secondary)
                        }
                    }
                }
                Text("近似匹配，仅供参考，并非 RAL 官方认证。")
                    .font(.caption)
                    .foregroundStyle(.tertiary)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }

            if workbench.isAnalyzing {
                ProgressView("正在匹配 RAL 并分解 Mixbox…")
                    .frame(maxWidth: .infinity, alignment: .leading)
            }

            if let analysisError = workbench.analysisError {
                Label(analysisError, systemImage: "exclamationmark.triangle")
                    .font(.caption)
                    .foregroundStyle(AppColor.destructive)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
        .contentCard()
        .alert(
            addNotice ?? "",
            isPresented: Binding(
                get: { addNotice != nil },
                set: { if !$0 { addNotice = nil } }
            )
        ) {
            Button("好", role: .cancel) {}
        }
    }

    private func addCurrentColorToBlend() {
        switch blendStore.addColor(
            hex: workbench.resultHex,
            name: workbench.resultName,
            source: .extract
        ) {
        case .added:
            blendStore.bannerMessage = L10n.addedToCustomMix(hex: workbench.resultHex)
            addFeedback += 1
            tuningSegment = "custom"
            selectedTabID = AppTab.tuning.rawValue
        case .duplicate:
            // Still jump so the user can adjust the existing swatch.
            blendStore.bannerMessage = String(localized: "该颜色已在自选列表中")
            tuningSegment = "custom"
            selectedTabID = AppTab.tuning.rawValue
        case .atCapacity:
            addNotice = L10n.customMixAtCapacity(BlendStore.maxColors)
        case .invalidHex:
            addNotice = String(localized: "颜色格式无效")
        }
    }
}

#Preview {
    MixerWorkbenchView()
}

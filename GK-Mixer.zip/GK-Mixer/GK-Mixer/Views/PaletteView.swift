import SwiftUI
import UIKit

struct PaletteView: View {
    @Environment(PaletteStore.self) private var store
    @State private var searchText = ""
    @State private var selectedCategoryID: UUID?
    @State private var selectedColor: SavedColor?
    @State private var showingNewCategory = false
    @State private var categoryToDelete: PaletteCategory?

    private let columns = Array(
        repeating: GridItem(.flexible(), spacing: Spacing.sm),
        count: 3
    )

    private var visibleColors: [SavedColor] {
        store.filtered(searchText: searchText, categoryID: selectedCategoryID)
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(spacing: Spacing.md) {
                    categoryBar

                    if visibleColors.isEmpty {
                        ContentUnavailableView {
                            Label(
                                searchText.isEmpty ? "调色板为空" : "没有匹配颜色",
                                systemImage: searchText.isEmpty
                                    ? "swatchpalette"
                                    : "magnifyingglass"
                            )
                        } description: {
                            Text(
                                searchText.isEmpty
                                    ? "请从混色台保存颜色"
                                    : "尝试其他 HEX、名称或分类"
                            )
                        }
                        .padding(.top, Spacing.xxl)
                    } else {
                        LazyVGrid(columns: columns, spacing: Spacing.sm) {
                            ForEach(visibleColors) { color in
                                PaletteColorCard(color: color) {
                                    selectedColor = color
                                }
                            }
                        }
                    }
                }
                .padding(.horizontal, Spacing.md)
                .padding(.bottom, Spacing.lg)
            }
            .background(AppColor.canvas)
            .navigationTitle("调色板")
            .compactSettingsAccess()
            .searchable(
                text: $searchText,
                placement: .navigationBarDrawer(displayMode: .always),
                prompt: "搜索 HEX 或颜色名称"
            )
            .sheet(isPresented: $showingNewCategory) {
                CategoryEditorSheet(title: String(localized: "新建分类")) { name in
                    guard let category = store.createCategory(named: name) else {
                        return false
                    }
                    selectedCategoryID = category.id
                    return true
                }
            }
            .sheet(item: $selectedColor) { color in
                PaletteDetailSheet(color: color)
            }
            .confirmationDialog(
                L10n.deleteCategoryConfirm(categoryToDelete?.name ?? ""),
                isPresented: Binding(
                    get: { categoryToDelete != nil },
                    set: { if !$0 { categoryToDelete = nil } }
                ),
                titleVisibility: .visible
            ) {
                Button("删除分类", role: .destructive) {
                    guard let categoryToDelete else { return }
                    if selectedCategoryID == categoryToDelete.id {
                        selectedCategoryID = nil
                    }
                    store.deleteCategory(categoryToDelete)
                    self.categoryToDelete = nil
                }
                Button("取消", role: .cancel) {}
            } message: {
                Text("分类中的颜色会保留，并移回未分类状态。")
            }
            .task {
                store.refresh()
            }
        }
    }

    private var categoryBar: some View {
        ScrollView(.horizontal) {
            HStack(spacing: Spacing.xs) {
                CategoryChip(
                    title: String(localized: "全部"),
                    count: store.colors.count,
                    isSelected: selectedCategoryID == nil
                ) {
                    selectedCategoryID = nil
                }

                ForEach(store.categories) { category in
                    CategoryChip(
                        title: category.name,
                        count: store.count(in: category),
                        isSelected: selectedCategoryID == category.id,
                        onDelete: { categoryToDelete = category }
                    ) {
                        selectedCategoryID = category.id
                    }
                }

                Button {
                    showingNewCategory = true
                } label: {
                    Image(systemName: "plus")
                        .font(.footnote.weight(.semibold))
                        .frame(minWidth: 32, minHeight: 32)
                }
                // Match bordered chips — `.glass` casts a soft halo that reads as a
                // stray shadow behind the category row on the canvas.
                .buttonStyle(.bordered)
                .buttonBorderShape(.circle)
                .controlSize(.small)
                .accessibilityLabel("新建分类")
            }
            .padding(.vertical, Spacing.xxs)
        }
        .scrollIndicators(.hidden)
    }
}

// MARK: - Category chip

private struct CategoryChip: View {
    let title: String
    let count: Int
    let isSelected: Bool
    var onDelete: (() -> Void)? = nil
    let action: () -> Void

    var body: some View {
        // Prefer Menu+primaryAction over contextMenu: the latter lifts a preview
        // whose soft shadow sits slightly offset behind bordered chips in this bar.
        Group {
            if let onDelete {
                Menu {
                    Button("删除分类", systemImage: "trash", role: .destructive, action: onDelete)
                } label: {
                    chipLabel
                } primaryAction: {
                    action()
                }
            } else {
                Button(action: action) {
                    chipLabel
                }
            }
        }
        .modifier(CategoryChipChrome(isSelected: isSelected))
    }

    private var chipLabel: some View {
        HStack(spacing: Spacing.xxs) {
            Text(title)
            Text("\(count)")
                .foregroundStyle(.secondary)
                .monospacedDigit()
        }
        .font(.footnote.weight(isSelected ? .semibold : .regular))
        .padding(.horizontal, Spacing.xs)
        .frame(minHeight: 32)
        .contentShape(Capsule())
    }
}

private struct CategoryChipChrome: ViewModifier {
    let isSelected: Bool

    func body(content: Content) -> some View {
        Group {
            if isSelected {
                content.buttonStyle(.borderedProminent)
            } else {
                content.buttonStyle(.bordered)
            }
        }
        .buttonBorderShape(.capsule)
        .controlSize(.small)
    }
}

// MARK: - Color card

private struct PaletteColorCard: View {
    let color: SavedColor
    let action: () -> Void

    @State private var copyTrigger = 0

    var body: some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 0) {
                RoundedRectangle(cornerRadius: CornerRadius.swatch, style: .continuous)
                    .fill(Color(hex: color.normalizedHex))
                    .frame(height: 60)
                    .overlay(alignment: .topTrailing) {
                        if let category = color.category {
                            Text(category.name)
                                .font(.caption2.weight(.semibold))
                                .lineLimit(1)
                                .padding(.horizontal, Spacing.xs)
                                .padding(.vertical, Spacing.xxs)
                                .background(.ultraThinMaterial, in: .capsule)
                                .padding(Spacing.xxs)
                        }
                    }

                VStack(alignment: .leading, spacing: 2) {
                    Text(color.normalizedHex)
                        .font(.caption.monospaced().weight(.semibold))
                    Text(LocalizedStringKey(color.name))
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
                .padding(Spacing.xs)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(
                RoundedRectangle(cornerRadius: CornerRadius.swatch, style: .continuous)
                    .fill(AppColor.surface)
            )
        }
        .buttonStyle(.plain)
        .simultaneousGesture(
            LongPressGesture(minimumDuration: 0.45)
                .onEnded { _ in
                    UIPasteboard.general.string = color.normalizedHex
                    copyTrigger += 1
                }
        )
        .sensoryFeedback(.success, trigger: copyTrigger)
        .accessibilityLabel(
            "\(color.name == L10n.untitledColorSentinel ? L10n.untitledColor : color.name)，\(color.normalizedHex)"
        )
        .accessibilityHint(String(localized: "点按打开详情，长按复制颜色代码"))
        .accessibilityAction(named: String(localized: "复制颜色代码")) {
            UIPasteboard.general.string = color.normalizedHex
            copyTrigger += 1
        }
    }
}

// MARK: - Detail sheet

private struct PaletteDetailSheet: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(PaletteStore.self) private var store
    @Environment(BlendStore.self) private var blendStore
    @AppStorage("selectedTabID") private var selectedTabID = AppTab.palette.rawValue
    @AppStorage("tuningWorkbenchSegment") private var tuningSegment = "custom"

    let color: SavedColor

    @State private var editedName = ""
    @State private var showingNewCategory = false
    @State private var confirmingDelete = false
    @State private var notice: String?

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: Spacing.lg) {
                    preview

                    VStack(spacing: Spacing.md) {
                        SectionHeader(title: "Mixbox 分解", icon: "chart.bar.fill")
                        MixboxDecompositionView(recipe: color.recipe)
                    }
                    .contentCard()

                    if let ral = color.ralMatch {
                        ralSection(ral)
                    }

                    categorySection
                    actionRow
                }
                .padding(.horizontal, Spacing.md)
                .padding(.bottom, Spacing.xl)
            }
            .background(AppColor.canvas)
            .navigationTitle("颜色详情")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("完成") {
                        store.rename(color, to: editedName)
                        dismiss()
                    }
                }
            }
            .onAppear {
                editedName = color.name
            }
            .sheet(isPresented: $showingNewCategory) {
                CategoryEditorSheet(title: String(localized: "新建分类")) { name in
                    guard let category = store.createCategory(named: name) else {
                        return false
                    }
                    store.assign(color, to: category)
                    return true
                }
            }
            .alert(
                notice ?? "",
                isPresented: Binding(
                    get: { notice != nil },
                    set: { if !$0 { notice = nil } }
                )
            ) {
                Button("好", role: .cancel) {}
            }
            .confirmationDialog(
                "确定删除这个颜色？",
                isPresented: $confirmingDelete,
                titleVisibility: .visible
            ) {
                Button("删除", role: .destructive) {
                    store.delete(color)
                    dismiss()
                }
                Button("取消", role: .cancel) {}
            } message: {
                Text("此操作无法撤销。")
            }
        }
        .presentationDetents([.medium, .large])
        .presentationDragIndicator(.visible)
    }

    private var preview: some View {
        VStack(alignment: .leading, spacing: Spacing.md) {
            RoundedRectangle(cornerRadius: CornerRadius.card, style: .continuous)
                .fill(Color(hex: color.normalizedHex))
                .frame(height: 180)
                .shadow(
                    color: Color(hex: color.normalizedHex).opacity(0.35),
                    radius: 18,
                    y: 8
                )

            Text(color.normalizedHex)
                .font(.title2.monospaced().bold())

            TextField("颜色名称", text: $editedName)
                .textFieldStyle(.roundedBorder)
                .submitLabel(.done)
                .onSubmit {
                    store.rename(color, to: editedName)
                }
        }
        .contentCard()
    }

    private var categorySection: some View {
        VStack(spacing: Spacing.md) {
            SectionHeader(title: "所属分类", icon: "folder")

            ScrollView(.horizontal) {
                HStack(spacing: Spacing.xs) {
                    CategoryChip(
                        title: String(localized: "未分类"),
                        count: store.colors.filter { $0.category == nil }.count,
                        isSelected: color.category == nil
                    ) {
                        store.assign(color, to: nil)
                    }

                    ForEach(store.categories) { category in
                        CategoryChip(
                            title: category.name,
                            count: store.count(in: category),
                            isSelected: color.category?.id == category.id
                        ) {
                            store.assign(color, to: category)
                        }
                    }

                    Button("新建", systemImage: "plus") {
                        showingNewCategory = true
                    }
                    .buttonStyle(.bordered)
                    .buttonBorderShape(.capsule)
                    .controlSize(.small)
                }
            }
            .scrollIndicators(.hidden)
        }
        .contentCard()
    }

    private func ralSection(_ ral: RALMatchSnapshot) -> some View {
        VStack(spacing: Spacing.md) {
            SectionHeader(title: "RAL 近似色", icon: "square.grid.3x3.fill")

            HStack(spacing: Spacing.sm) {
                RoundedRectangle(cornerRadius: CornerRadius.swatch, style: .continuous)
                    .fill(Color(hex: ral.standardHex))
                    .frame(width: 64, height: 64)
                    .overlay(
                        RoundedRectangle(
                            cornerRadius: CornerRadius.swatch,
                            style: .continuous
                        )
                        .strokeBorder(.primary.opacity(0.12))
                    )

                VStack(alignment: .leading, spacing: Spacing.xxs) {
                    Text(verbatim: "RAL \(ral.number) \(ral.name)")
                        .font(.headline)
                    Text("\(ral.standardHex) · LRV \(ral.lrv.formatted())")
                        .font(.caption.monospaced())
                        .foregroundStyle(.secondary)
                    Text("近似匹配，非 RAL 官方认证")
                        .font(.caption)
                        .foregroundStyle(.tertiary)
                }
                Spacer(minLength: 0)
            }
        }
        .contentCard()
    }

    private var actionRow: some View {
        HStack(spacing: Spacing.sm) {
            Button("加入自选调色", systemImage: "plus.square.fill") {
                addToCustomBlend()
            }
            .buttonStyle(.glassProminent)

            ShareLink(
                item: shareText,
                subject: Text(LocalizedStringKey(color.name)),
                message: Text("GK Mixer 调色板颜色")
            ) {
                Image(systemName: "square.and.arrow.up")
            }
            .buttonStyle(.glass)
            .accessibilityLabel("分享")

            Button("删除", systemImage: "trash", role: .destructive) {
                confirmingDelete = true
            }
            .labelStyle(.iconOnly)
            .buttonStyle(.glass)
            .tint(.red)
            .accessibilityLabel("删除")
        }
        .controlSize(.large)
    }

    private func addToCustomBlend() {
        switch blendStore.addColor(
            hex: color.normalizedHex,
            name: color.name,
            source: .extract
        ) {
        case .added:
            blendStore.bannerMessage = L10n.addedToCustomMix(hex: color.normalizedHex)
            tuningSegment = "custom"
            selectedTabID = AppTab.tuning.rawValue
            dismiss()
        case .duplicate:
            blendStore.bannerMessage = String(localized: "该颜色已在自选列表中")
            tuningSegment = "custom"
            selectedTabID = AppTab.tuning.rawValue
            dismiss()
        case .atCapacity:
            notice = L10n.customMixAtCapacity(BlendStore.maxColors)
        case .invalidHex:
            notice = String(localized: "颜色格式无效")
        }
    }

    private var shareText: String {
        let displayName = color.name == L10n.untitledColorSentinel
            ? L10n.untitledColor
            : color.name
        let ratios = color.recipe?.components
            .filter { $0.weight > 0.001 }
            .map {
                "\(L10n.localizedPigmentName($0.name)) \($0.weight.formatted(.percent.precision(.fractionLength(0))))"
            }
            .joined(separator: " · ") ?? String(localized: "暂无 Mixbox 分解")
        return "\(displayName)\n\(color.normalizedHex)\n\(ratios)"
    }
}

// MARK: - Category editor

private struct CategoryEditorSheet: View {
    @Environment(\.dismiss) private var dismiss
    let title: String
    let onSave: (String) -> Bool

    @State private var name = ""
    @State private var validationMessage: String?

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("分类名称", text: $name)
                        .textInputAutocapitalization(.never)
                        .submitLabel(.done)
                        .onSubmit(save)
                } footer: {
                    if let validationMessage {
                        Text(validationMessage)
                            .foregroundStyle(.red)
                    }
                }
            }
            .navigationTitle(title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消", role: .cancel) {
                        dismiss()
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("创建", action: save)
                        .disabled(
                            name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                        )
                }
            }
        }
        .presentationDetents([.height(190)])
    }

    private func save() {
        if onSave(name) {
            dismiss()
        } else {
            validationMessage = String(localized: "名称为空或已经存在")
        }
    }
}

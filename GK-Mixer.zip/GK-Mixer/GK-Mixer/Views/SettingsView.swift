import StoreKit
import SwiftUI
import UIKit

struct SettingsView: View {
    /// When presented from the compact-dock menu button.
    var isModal = false

    @AppStorage("colorScheme") private var appearance: Appearance = .system
    @AppStorage(AppAccent.storageKey) private var accentHex = AppAccent.defaultHex
    @AppStorage("compactDockEnabled") private var compactDockEnabled = false
    @AppStorage("selectedTabID") private var selectedTabID = AppTab.workbench.rawValue
    @AppStorage("openSettingsAfterCompact") private var openSettingsAfterCompact = false
    @Environment(\.openURL) private var openURL
    @Environment(\.requestReview) private var requestReview
    @Environment(\.dismiss) private var dismiss
    @State private var iCloud = iCloudSyncStatus()
    @State private var isDockTransitioning = false
    /// Keeps the Toggle visually in sync during sequenced 4→3 handoff.
    @State private var compactDockToggleValue = false
    @State private var accentDraft = AppAccent.defaultHex
    @State private var accentInputInvalid = false

    var body: some View {
        NavigationStack {
            Form {
                // 1. Language — hand off to system Preferred Language
                Section {
                    Button {
                        openSystemSettings()
                    } label: {
                        LabeledContent {
                            HStack(spacing: Spacing.xxs) {
                                Text(iCloud.currentLanguageLabel)
                                    .foregroundStyle(.secondary)
                                Image(systemName: "chevron.forward")
                                    .font(.caption.weight(.semibold))
                                    .foregroundStyle(.tertiary)
                            }
                        } label: {
                            Label("语言", systemImage: "globe")
                        }
                    }
                    .tint(.primary)
                } footer: {
                    Text("使用系统原生的 App 语言设置。点按后可在「设置」中切换中文、English、日本語等。")
                }

                // 2. iCloud account availability (no CloudKit entitlement required)
                Section {
                    LabeledContent {
                        Text(iCloud.statusLabel)
                            .foregroundStyle(iCloud.statusColor)
                    } label: {
                        Label("iCloud 同步", systemImage: "icloud")
                    }
                } footer: {
                    Text(iCloud.footerText)
                }

                // 3. Appearance + accent + compact dock
                Section {
                    Picker(selection: $appearance) {
                        ForEach(Appearance.allCases) { option in
                            Text(option.label).tag(option)
                        }
                    } label: {
                        Label("主题", systemImage: "circle.lefthalf.filled")
                    }

                    accentColorRow

                    if Color.normalizedHex(accentHex)?.uppercased() != AppAccent.defaultHex {
                        Button("恢复默认强调色") {
                            applyAccent(AppAccent.defaultHex)
                        }
                    }

                    Toggle(isOn: compactDockBinding) {
                        Label("精简 Dock", systemImage: "menubar.rectangle")
                    }
                    .disabled(isDockTransitioning)
                    .sensoryFeedback(.selection, trigger: compactDockEnabled)
                } header: {
                    Text("外观")
                } footer: {
                    Text("强调色用于 Tab、按钮等选中态。输入 6 位 HEX（如 #FF9900）后点应用。开启精简 Dock 后底部只保留混色台、调色、调色板；设置入口移到导航栏右上角圆形按钮。")
                }

                // 4. Advanced (unchanged)
                Section("高级功能") {
                    LabeledContent {
                        Text("Mixbox")
                    } label: {
                        Label("混色算法", systemImage: "cpu")
                    }

                    LabeledContent {
                        Text("Classic (213色)")
                    } label: {
                        Label("RAL 色库版本", systemImage: "swatchpalette")
                    }
                }

                // 5. About
                Section {
                    LabeledContent {
                        Text(Self.appVersion)
                            .monospaced()
                            .foregroundStyle(.secondary)
                    } label: {
                        Label("版本", systemImage: "info.circle")
                    }

                    Button {
                        requestReview()
                    } label: {
                        Label("在 App Store 评分", systemImage: "star.fill")
                    }

                    socialLinksRow
                        .listRowInsets(
                            EdgeInsets(
                                top: Spacing.md,
                                leading: Spacing.md,
                                bottom: Spacing.md,
                                trailing: Spacing.md
                            )
                        )
                } header: {
                    Text("关于")
                        .font(.title2.weight(.bold))
                        .foregroundStyle(.primary)
                        .textCase(nil)
                        .padding(.bottom, Spacing.xxs)
                }

                Section("特别鸣谢") {
                    LabeledContent {
                        Text("UI 设计 · 色彩顾问")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    } label: {
                        Label("スミレ", systemImage: "sparkles")
                    }
                }
            }
            .navigationTitle("设置")
            .toolbar {
                if isModal {
                    ToolbarItem(placement: .confirmationAction) {
                        Button("完成") {
                            dismiss()
                        }
                    }
                }
            }
            .onAppear {
                compactDockToggleValue = compactDockEnabled
                accentDraft = Color.normalizedHex(accentHex) ?? AppAccent.defaultHex
                iCloud.refresh()
            }
            .refreshable {
                iCloud.refresh()
            }
            .onChange(of: accentHex) { _, newValue in
                accentDraft = Color.normalizedHex(newValue) ?? AppAccent.defaultHex
                accentInputInvalid = false
            }
            .onChange(of: compactDockEnabled) { _, enabled in
                compactDockToggleValue = enabled
                // 3→4: let the dock morph under the sheet, then dismiss.
                guard isModal, !enabled else { return }
                Task { @MainActor in
                    try? await Task.sleep(for: .milliseconds(220))
                    dismiss()
                }
            }
        }
    }

    private var accentColorRow: some View {
        VStack(alignment: .leading, spacing: Spacing.xs) {
            Label("强调色", systemImage: "paintpalette.fill")

            HStack(spacing: Spacing.sm) {
                RoundedRectangle(cornerRadius: 6, style: .continuous)
                    .fill(Color(hex: Color.normalizedHex(accentDraft) ?? accentHex))
                    .frame(width: 28, height: 28)
                    .overlay {
                        RoundedRectangle(cornerRadius: 6, style: .continuous)
                            .strokeBorder(.quaternary, lineWidth: 1)
                    }
                    .accessibilityHidden(true)

                TextField("#FF9900", text: $accentDraft)
                    .textInputAutocapitalization(.characters)
                    .autocorrectionDisabled()
                    .keyboardType(.asciiCapable)
                    .font(.body.monospaced())
                    .onChange(of: accentDraft) { _, _ in
                        accentInputInvalid = false
                    }
                    .onSubmit(commitAccentDraft)

                Button("应用", action: commitAccentDraft)
                    .disabled(Color.normalizedHex(accentDraft) == nil)
            }

            if accentInputInvalid {
                Text("请输入有效的 6 位 HEX，例如 #FF9900")
                    .font(.caption)
                    .foregroundStyle(AppColor.destructive)
            }
        }
        .accessibilityElement(children: .contain)
    }

    private func commitAccentDraft() {
        guard let normalized = Color.normalizedHex(accentDraft) else {
            accentInputInvalid = true
            return
        }
        applyAccent(normalized)
    }

    private func applyAccent(_ hex: String) {
        accentInputInvalid = false
        accentDraft = hex
        accentHex = hex
    }

    /// Animates TabView / toolbar chrome with the system smooth curve.
    /// 4→3 from the Settings tab: leave the tab first, then collapse the dock.
    /// 3→4 from the menu sheet: morph the dock, then dismiss the sheet.
    private var compactDockBinding: Binding<Bool> {
        Binding(
            get: { compactDockToggleValue },
            set: { newValue in
                compactDockToggleValue = newValue
                if newValue, !compactDockEnabled, !isModal {
                    enableCompactDockFromTab()
                } else {
                    withAnimation(AppAnimation.dockChrome) {
                        compactDockEnabled = newValue
                    }
                }
            }
        )
    }

    private func enableCompactDockFromTab() {
        guard !isDockTransitioning else { return }
        isDockTransitioning = true
        openSettingsAfterCompact = true

        withAnimation(AppAnimation.dockChrome) {
            selectedTabID = AppTab.workbench.rawValue
        }

        Task { @MainActor in
            try? await Task.sleep(for: .milliseconds(220))
            withAnimation(AppAnimation.dockChrome) {
                compactDockEnabled = true
            }
            isDockTransitioning = false
        }
    }

    // MARK: - Social (circular Liquid Glass)

    private var socialLinksRow: some View {
        HStack(spacing: Spacing.xl) {
            SocialGlassLink(
                title: "Bilibili",
                assetName: "SocialBilibili",
                url: URL(string: "https://space.bilibili.com/23848833")!
            )
            SocialGlassLink(
                title: "X",
                assetName: "SocialX",
                url: URL(string: "https://x.com/rfQ4nGLccl4bqCP")!
            )
            SocialGlassLink(
                title: String(localized: "讨论群"),
                systemImage: "ellipsis.message.fill",
                tint: BrandColor.qq,
                url: URL(string: "https://qm.qq.com/q/QtX0ZBOWIe")!
            )
        }
        .frame(maxWidth: .infinity)
        .accessibilityElement(children: .contain)
    }

    private func openSystemSettings() {
        guard let url = URL(string: UIApplication.openSettingsURLString) else { return }
        openURL(url)
    }

    private static var appVersion: String {
        let short = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "—"
        let build = Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "—"
        return "\(short) (\(build))"
    }
}

// MARK: - Circular glass social button

private struct SocialGlassLink: View {
    let title: String
    var assetName: String? = nil
    var systemImage: String? = nil
    var tint: Color = .primary
    let url: URL

    private let buttonSize: CGFloat = Spacing.touch + 8

    var body: some View {
        Link(destination: url) {
            VStack(spacing: Spacing.xs) {
                icon
                    .frame(width: buttonSize, height: buttonSize)
                    .glassEffect(.regular.interactive(), in: .circle)
                    .clipShape(Circle())

                Text(title)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
        }
        .buttonStyle(.plain)
        .accessibilityLabel(title)
    }

    @ViewBuilder
    private var icon: some View {
        if let assetName {
            Image(assetName)
                .resizable()
                .scaledToFill()
                .frame(width: buttonSize, height: buttonSize)
                .clipShape(Circle())
        } else if let systemImage {
            Image(systemName: systemImage)
                .font(.title3.weight(.semibold))
                .foregroundStyle(tint)
        }
    }
}

// MARK: - Native iCloud status

/// Reads Apple account / iCloud availability without CloudKit.
/// `CKContainer.default()` traps when the app has no iCloud entitlement, so we
/// only use `FileManager.ubiquityIdentityToken` until CloudKit is enabled.
@MainActor
@Observable
final class iCloudSyncStatus {
    private(set) var hasUbiquityIdentity = false

    var currentLanguageLabel: String {
        let code = Locale.current.language.languageCode?.identifier ?? Locale.current.identifier
        return Locale.current.localizedString(forLanguageCode: code)
            ?? Locale.current.localizedString(forIdentifier: Locale.current.identifier)
            ?? code
    }

    var statusLabel: String {
        hasUbiquityIdentity
            ? String(localized: "已登录")
            : String(localized: "未登录")
    }

    var statusColor: Color {
        hasUbiquityIdentity ? AppColor.success : AppColor.neutral
    }

    var footerText: String {
        if hasUbiquityIdentity {
            String(localized: "当前设备已登录 iCloud。调色板跨设备同步将在启用 CloudKit 能力后生效。")
        } else {
            String(localized: "请在系统设置中登录 Apple 账户并开启 iCloud，以便后续同步调色板。")
        }
    }

    func refresh() {
        hasUbiquityIdentity = FileManager.default.ubiquityIdentityToken != nil
    }
}

#Preview {
    SettingsView()
}

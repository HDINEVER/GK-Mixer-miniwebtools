import SwiftUI

struct TuningWorkbenchView: View {
    private enum Segment: String, CaseIterable, Identifiable {
        case custom
        case basic

        var id: Self { self }

        var title: String {
            switch self {
            case .custom: String(localized: "自选")
            case .basic: String(localized: "基础")
            }
        }
    }

    @AppStorage("tuningWorkbenchSegment") private var segment: Segment = .custom

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                Picker("调色方式", selection: $segment) {
                    ForEach(Segment.allCases) { segment in
                        Text(segment.title).tag(segment)
                    }
                }
                .pickerStyle(.segmented)
                .padding(.horizontal, Spacing.md)
                .padding(.bottom, Spacing.md)

                Group {
                    switch segment {
                    case .custom:
                        BlendView()
                    case .basic:
                        BasicMixerView()
                    }
                }
            }
            .background(AppColor.canvas)
            .navigationTitle("调色")
            .compactSettingsAccess()
        }
    }
}

#Preview {
    TuningWorkbenchView()
}

import Foundation
import Testing
@testable import GK_Mixer

@Suite(.serialized)
struct ColorAlgorithmRuntimeTests {
    @Test
    func loadsExpectedBundleVersion() async throws {
        let version = try await ColorAlgorithmRuntime.shared.bundleVersion()
        #expect(version == 1)
    }

    @Test
    func legacyDecompositionReturnsEightNormalizedComponents() async throws {
        let recipe = try await ColorAlgorithmRuntime.shared.decompose(hex: "#8D93AD")

        #expect(recipe.paletteID == .legacyExtended8)
        #expect(recipe.components.count == 8)
        #expect(abs(recipe.components.reduce(0) { $0 + $1.weight } - 1) < 0.000_001)
        #expect(recipe.components[4].id == "legacy-004")
        #expect(abs(recipe.components[4].weight - 0.374_277_031) < 0.000_001)
    }

    @Test
    func grayscaleWebCompatibilityStillReturnsEightComponents() async throws {
        let recipe = try await ColorAlgorithmRuntime.shared.decompose(hex: "#808080")

        #expect(recipe.components.count == 8)
        #expect(recipe.components.dropFirst(2).allSatisfy { $0.weight == 0 })
        #expect(abs(recipe.components.reduce(0) { $0 + $1.weight } - 1) < 0.000_001)
    }

    @Test
    func basicBlueAndYellowUseWebMixboxForwardModel() async throws {
        let result = try #require(
            try await ColorAlgorithmRuntime.shared.mixBasic(
                weights: [0, 0, 0, 1, 1, 0, 0, 0]
            )
        )

        #expect(result.hex == "#36983C")
        #expect(result.recipe.paletteID == .gaiaProcess8)
        #expect(result.components[3].weight == 0.5)
        #expect(result.components[4].weight == 0.5)
    }

    @Test
    func mixMultiMatchesBasicMixerForSharedPigments() async throws {
        let result = try #require(
            try await ColorAlgorithmRuntime.shared.mixMulti(
                colors: [
                    (hex: "#004098", weight: 1),
                    (hex: "#FFD900", weight: 1),
                ]
            )
        )
        #expect(result.hex == "#36983C")
    }

    @MainActor
    @Test
    func blendStoreAddsExtractedColorAndMixes() async throws {
        let store = BlendStore()
        #expect(store.addColor(hex: "#004098", name: "蓝", source: .extract) == .added)
        #expect(store.addColor(hex: "#FFD900", name: "黄", source: .extract) == .added)
        #expect(store.addColor(hex: "#004098", source: .extract) == .duplicate)

        store.colors[0].amount = 50
        store.colors[1].amount = 50
        await store.recalculate()

        #expect(store.resultHex == "#36983C")
        #expect(store.ralMatch != nil)
    }

    @Test
    func ralMatchUsesCanonicalStandardColor() async throws {
        let ral = try #require(
            try await ColorAlgorithmRuntime.shared.nearestRAL(hex: "#703731")
        )

        #expect(ral.number == 3009)
        #expect(ral.name == "Oxide Red")
        #expect(ral.standardHex == "#663029")
    }

    @MainActor
    @Test
    func basicMixerStorePublishesResultRecipeAndRAL() async throws {
        let store = BasicMixerStore()
        store.paintAmounts[3] = 1
        store.paintAmounts[4] = 1

        await store.recalculate()

        #expect(store.result?.hex == "#36983C")
        #expect(store.result?.recipe.paletteID == .gaiaProcess8)
        #expect(store.ralMatch != nil)

        store.reset()
        #expect(store.result == nil)
        #expect(store.totalParts == 0)
    }

    @Test
    func versionOneRecipeDefaultsToGaiaPalette() throws {
        let data = Data(
            """
            {"version":1,"components":[
              {"id":"white","name":"白","hex":"#FFFFFF","weight":1}
            ]}
            """.utf8
        )
        let recipe = try JSONDecoder().decode(MixboxRecipeSnapshot.self, from: data)

        #expect(recipe.version == 1)
        #expect(recipe.paletteID == .gaiaProcess8)
    }
}

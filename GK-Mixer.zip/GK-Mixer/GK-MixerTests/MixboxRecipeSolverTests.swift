import Foundation
import Testing
@testable import GK_Mixer

@Suite(.serialized)
struct MixboxRecipeSolverTests {
    private let expectedIDs = [
        "white", "black", "red", "blue", "yellow",
        "sourceYellow", "sourceCyan", "sourceMagenta",
    ]

    @Test func eightPigmentVerticesRegressToThemselves() {
        #expect(MixboxEngine.pigments.map(\.id) == expectedIDs)

        for (index, pigment) in MixboxEngine.pigments.enumerated() {
            let result = MixboxRecipeSolver.solve(hex: pigment.hex)
            #expect(result.map(\.id) == expectedIDs)
            #expect(abs(result.reduce(0) { $0 + $1.weight } - 1) < 1e-12)
            #expect(result[index].weight > 0.999999)
            #expect(result.enumerated().allSatisfy { item in
                item.offset == index || item.element.weight < 1e-12
            })
        }
    }

    @Test func compositeColorsUseNormalizedMixboxRecipes() {
        let targets = ["#7F6A3C", "#3C7F73", "#B45A88", "#6C78A8", "#E8B06A"]

        for targetHex in targets {
            let result = MixboxRecipeSolver.solve(hex: targetHex)
            #expect(result.count == 8)
            #expect(result.map(\.id) == expectedIDs)
            #expect(result.allSatisfy { (0...1).contains($0.weight) })
            #expect(abs(result.reduce(0) { $0 + $1.weight } - 1) < 1e-10)

            let target = MixboxEngine.parse(hex: targetHex)!
            let reconstructed = MixboxEngine.mix(weights: result.map(\.weight))!
            #expect(channelError(reconstructed, target) < 0.16)
        }
    }

    @Test func knownMixturesCanBeRecoveredThroughForwardModel() {
        let recipes: [[Double]] = [
            [0, 0, 0, 0.5, 0.5, 0, 0, 0],
            [0.35, 0, 0.35, 0, 0, 0, 0, 0.30],
            [0.15, 0.20, 0, 0.10, 0, 0.25, 0.30, 0],
        ]

        for recipe in recipes {
            let target = MixboxEngine.mix(weights: recipe)!
            let result = MixboxRecipeSolver.solve(hex: hex(target))
            let reconstructed = MixboxEngine.mix(weights: result.map(\.weight))!
            #expect(channelError(reconstructed, target) < 0.08)
            #expect(abs(result.reduce(0) { $0 + $1.weight } - 1) < 1e-10)
        }
    }

    @Test func blueAndYellowUseSubtractiveMixboxForwardModel() {
        let mixed = MixboxEngine.mix(weights: [0, 0, 0, 0.5, 0.5, 0, 0, 0])!

        // RGB 平均会接近 (0.5, 0.55, 0.30)；Mixbox 颜料混合明显偏绿且蓝通道更低。
        #expect(mixed.g > mixed.r)
        #expect(mixed.g > mixed.b)
        #expect(mixed.b < 0.25)
    }

    @Test func invalidHexFailsSafely() {
        for invalid in ["", "#FFF", "#GG0000", "12345", "#12345678", "not-a-color"] {
            #expect(MixboxRecipeSolver.solve(hex: invalid).isEmpty)
        }
    }

    private func channelError(_ lhs: MixboxEngine.RGB, _ rhs: MixboxEngine.RGB) -> Double {
        max(abs(lhs.r - rhs.r), abs(lhs.g - rhs.g), abs(lhs.b - rhs.b))
    }

    private func hex(_ rgb: MixboxEngine.RGB) -> String {
        let r = Int((rgb.r * 255).rounded())
        let g = Int((rgb.g * 255).rounded())
        let b = Int((rgb.b * 255).rounded())
        return String(format: "#%02X%02X%02X", r, g, b)
    }
}

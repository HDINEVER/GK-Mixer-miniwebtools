import SwiftData
import Testing
@testable import GK_Mixer

@MainActor
@Suite(.serialized)
struct PaletteStoreTests {
    @Test
    func normalizesHexAndAvoidsDuplicates() throws {
        let harness = try makeStore()
        let store = harness.store
        let recipe = sampleRecipe()

        #expect(
            store.saveFromMixer(hex: " ff0090 ", name: "品红", recipe: recipe)
                == .inserted
        )
        #expect(
            store.saveFromMixer(hex: "#FF0090", name: "另一个名称", recipe: recipe)
                == .updatedExisting
        )
        #expect(store.colors.count == 1)
        #expect(store.colors.first?.normalizedHex == "#FF0090")
        #expect(store.colors.first?.name == "品红")
    }

    @Test
    func filtersByCategoryAndSearchTogether() throws {
        let harness = try makeStore()
        let store = harness.store
        let recipe = sampleRecipe()
        _ = store.saveFromMixer(hex: "#FF0000", name: "红色", recipe: recipe)
        _ = store.saveFromMixer(hex: "#0000FF", name: "蓝色", recipe: recipe)

        let category = try #require(store.createCategory(named: "暖色"))
        let red = try #require(store.colors.first { $0.normalizedHex == "#FF0000" })
        store.assign(red, to: category)

        #expect(store.filtered(searchText: "", categoryID: category.id).count == 1)
        #expect(store.filtered(searchText: "红", categoryID: category.id).count == 1)
        #expect(store.filtered(searchText: "蓝", categoryID: category.id).isEmpty)
        #expect(store.filtered(searchText: "0000ff", categoryID: nil).count == 1)
    }

    @Test
    func deletingCategoryKeepsColors() throws {
        let harness = try makeStore()
        let store = harness.store
        _ = store.saveFromMixer(
            hex: "#FFEF00",
            name: "色源黄",
            recipe: sampleRecipe()
        )
        let category = try #require(store.createCategory(named: "色源"))
        let color = try #require(store.colors.first)
        store.assign(color, to: category)

        store.deleteCategory(category)

        #expect(store.colors.count == 1)
        #expect(store.colors.first?.category == nil)
        #expect(store.categories.isEmpty)
    }

    private struct Harness {
        let container: ModelContainer
        let store: PaletteStore
    }

    private func makeStore() throws -> Harness {
        let configuration = ModelConfiguration(isStoredInMemoryOnly: true)
        let container = try ModelContainer(
            for: SavedColor.self,
            PaletteCategory.self,
            configurations: configuration
        )
        return Harness(
            container: container,
            store: PaletteStore(modelContext: container.mainContext)
        )
    }

    private func sampleRecipe() -> MixboxRecipeSnapshot {
        MixboxRecipeSnapshot(
            components: MixboxRecipeSnapshot.pigmentOrder.enumerated().map {
                index, pigment in
                MixboxRecipeComponent(
                    id: pigment.id,
                    name: pigment.name,
                    hex: pigment.hex,
                    weight: index == 0 ? 1 : 0
                )
            }
        )
    }
}

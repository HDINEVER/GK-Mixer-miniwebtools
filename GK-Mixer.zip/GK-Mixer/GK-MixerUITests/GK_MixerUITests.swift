//
//  GK_MixerUITests.swift
//  GK-MixerUITests
//
//  Created by Kroos Huang on 2026/2/5.
//

import XCTest

final class GK_MixerUITests: XCTestCase {

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.

        // In UI tests it is usually best to stop immediately when a failure occurs.
        continueAfterFailure = false

        // In UI tests it’s important to set the initial state - such as interface orientation - required for your tests before they run. The setUp method is a good place to do this.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    @MainActor
    func testMixerSavesIntoPaletteAndOpensDetail() throws {
        let app = XCUIApplication()
        app.launchArguments = ["-selectedTabID", "workbench"]
        app.launch()

        let mixerSegment = app.buttons["混色"].firstMatch
        XCTAssertTrue(mixerSegment.waitForExistence(timeout: 5))
        mixerSegment.tap()

        let saveButton = app.buttons["保存到调色板"]
        XCTAssertTrue(saveButton.waitForExistence(timeout: 5))

        let enabled = NSPredicate(format: "enabled == true")
        expectation(for: enabled, evaluatedWith: saveButton)
        waitForExpectations(timeout: 8)
        saveButton.tap()

        let acknowledgement = app.alerts.buttons["好"]
        XCTAssertTrue(acknowledgement.waitForExistence(timeout: 5))
        acknowledgement.tap()

        app.tabBars.buttons["调色板"].tap()

        let savedHex = app.staticTexts["#FF9900"].firstMatch
        XCTAssertTrue(savedHex.waitForExistence(timeout: 5))
        savedHex.tap()

        XCTAssertTrue(app.navigationBars["颜色详情"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.staticTexts["Mixbox 分解"].exists)
    }

    @MainActor
    func testBasicMixerProducesWebMixboxResult() throws {
        let app = XCUIApplication()
        app.launchArguments = [
            "-selectedTabID", "tuning",
            "-tuningWorkbenchSegment", "basic",
        ]
        app.launch()

        let blueSlider = app.sliders["蓝"]
        let yellowSlider = app.sliders["黄"]
        XCTAssertTrue(blueSlider.waitForExistence(timeout: 5))
        XCTAssertTrue(yellowSlider.exists)

        blueSlider.adjust(toNormalizedSliderPosition: 0.5)
        yellowSlider.adjust(toNormalizedSliderPosition: 0.5)

        let hexValue = app.staticTexts.matching(
            NSPredicate(format: "label MATCHES '#[0-9A-F]{6}'")
        ).firstMatch
        XCTAssertTrue(hexValue.waitForExistence(timeout: 5))
        XCTAssertTrue(app.buttons["保存配方"].isEnabled)
    }

    @MainActor
    func testLaunchPerformance() throws {
        // This measures how long it takes to launch your application.
        measure(metrics: [XCTApplicationLaunchMetric()]) {
            XCUIApplication().launch()
        }
    }
}

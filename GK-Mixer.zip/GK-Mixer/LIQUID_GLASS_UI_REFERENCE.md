# GK-Mixer · Liquid Glass UI 项目参考

> **用途**：Web → Native SwiftUI 改造时的界面验收与实现规范。  
> **范围**：iOS 26 / Xcode 26 SDK，优先标准系统组件自动获得 Liquid Glass。  
> **配套**：快速入门见 [`LIQUID_GLASS_QUICKSTART.md`](./LIQUID_GLASS_QUICKSTART.md)

---

## 0. 一句话原则

**内容层实、控件层玻璃、过渡有来源、圆角同心、间距系统化、外观自适应。**

不要把 Web 的卡片、硬分割线、固定背景色、汉堡菜单照搬进 SwiftUI。优先 `TabView` / `NavigationStack` / `Toolbar` / `Sheet` / `List`，让系统材质与滚动边缘效果自动工作。

---

## 1. 分层模型（必须遵守）

| 层 | 放什么 | 材质 | 反例 |
|----|--------|------|------|
| **内容层** | 色板、混色预览、图片、配方列表、图表 | 不透明或语义背景 | 给整页加玻璃 |
| **功能层（Liquid Glass）** | Tab、Toolbar、搜索、浮动按钮、Sheet 背景 | 系统玻璃 / `.glassEffect` | 在内容卡片上滥用玻璃 |
| **瞬时层** | Menu、Alert、ConfirmationDialog、Popover | 从触发控件涌出 | 从屏幕底部机械弹出且无来源 |

```
┌─────────────────────────────────────┐
│  瞬时层：Menu / Sheet / Dialog      │  ← 从按钮“涌出”
├─────────────────────────────────────┤
│  功能层：TabBar / Toolbar / Capsule │  ← Liquid Glass，悬浮
├─────────────────────────────────────┤
│  内容层：色板 / 预览 / ScrollView    │  ← 主角，可在玻璃下滚动
└─────────────────────────────────────┘
```

**GK-Mixer 映射**

| Tab | 内容层 | 功能层建议 |
|-----|--------|------------|
| 混色台 Workbench | 拾色页：源图像 + 原生 ColorPicker + RAL 色卡；混色页：目标容量与 Mixbox 毫升配方 | 系统分段 Picker；保存到调色板用 `.glassProminent` |
| 调色 Tuning | 分段整合径向自选与 8 色基础颜料实时混合 | 系统分段 Picker；内容区保持实色 |
| 调色板 Palette | 已保存颜色、分类、Mixbox 分解与 RAL 信息 | 系统搜索、分类 Chip、原生详情 Sheet |
| 设置 Settings | Grouped List | 系统 List 即可，勿包一层自定义玻璃卡片 |

---

## 2. Padding 与间距系统

### 2.1 Token（统一使用，禁止随意 pt）

| Token | 值 | 用途 |
|-------|-----|------|
| `xxs` | 4 | 图标与文字微间隙 |
| `xs` | 8 | 控件内部、相关元素 |
| `sm` | 12 | 紧凑组内间距 |
| `md` | 16 | **默认内容边距**（多数屏幕左右） |
| `lg` | 20 | 大屏/宽松内容边距 |
| `xl` | 24 | 区块之间 |
| `xxl` | 32 | 大区块分隔 |
| Touch | **≥ 44×44** | 所有可点目标 |

SwiftUI 建议集中定义：

```swift
enum Spacing {
    static let xxs: CGFloat = 4
    static let xs: CGFloat = 8
    static let sm: CGFloat = 12
    static let md: CGFloat = 16
    static let lg: CGFloat = 20
    static let xl: CGFloat = 24
    static let xxl: CGFloat = 32
    static let touch: CGFloat = 44
}
```

### 2.2 布局规则

- 屏幕左右内容边距：`16–20`，列表用系统 `List`/`InsetGroupedListStyle` 默认 inset。
- Safe Area：交互元素永不压在 Dynamic Island / Home Indicator 下；仅装饰背景可用 `.ignoresSafeArea()`。
- Dynamic Type：自定义间距用 `@ScaledMetric`，字体用语义样式（`.title` / `.body` / `.caption`），禁止写死 `font(.system(size: 14))`。
- Web 改造对照：Tailwind `p-4` ≈ `md(16)`；`gap-2` ≈ `xs(8)`；不要把 CSS 的 `px` 当 `pt` 硬抄。

### 2.3 自动排列（优先声明式栈，而非绝对定位）

| 场景 | API |
|------|-----|
| 纵向主结构 | `VStack` / `LazyVStack` |
| 横向工具组 | `HStack` + `Spacer` |
| 等分色块 | `Grid` / `LazyVGrid` |
| 自适应换行标签 | `ViewThatFits` 或 `Layout` / Flow |
| 表单 | `Form` / `List` + `Section` |
| 对齐到容器圆角 | `.containerRelativeFrame` + 同心圆角 |

禁止：大量 `position(x:y:)`、Web 式 absolute 叠层。混色预览可以全宽，但控件用 `safeAreaInset` 或 Toolbar 挂载。

---

## 3. Liquid Glass 采用清单

### 3.1 自动获得（先做这些）

用 Xcode 26 SDK 编译后，下列组件**默认**带 Liquid Glass：

- `TabView`（悬浮 Tab，可滚动最小化）
- `NavigationStack` / `NavigationSplitView` 工具栏与侧栏
- `Toolbar` / 系统按钮
- 半高 `Sheet`（inset + 玻璃背景）
- `Menu` / `Alert` / `confirmationDialog` / `Popover`

**必做清理（Web 残留）**

1. 删除导航/Tab 上的自定义不透明背景、渐变条、硬分割线。
2. 删除 sheet 上多余的 `.presentationBackground`（除非有强理由）。
3. 删除“为了层级”而加的第二层 `systemGray6` 大卡片底。
4. 图标优先单色 SF Symbols；`tint` 只用于语义（如混色强调色 orange），不为装饰。

### 3.2 自定义玻璃（仅功能层）

```swift
// 默认胶囊玻璃
Label("取样", systemImage: "eyedropper")
    .padding(.horizontal, Spacing.md)
    .padding(.vertical, Spacing.xs)
    .glassEffect()

// 形状 / 色调 / 可交互
.glassEffect(.regular.interactive().tint(.orange.opacity(0.45)), in: .capsule)

// 多块玻璃必须同容器，才能正确折射与 morph
GlassEffectContainer {
    HStack(spacing: Spacing.xs) {
        // 多个 .glassEffect 子视图
    }
}
```

| 变体 | 何时用 |
|------|--------|
| `.regular` | 默认浮动控件 |
| `.clear` | 盖在丰富媒体上且前景够粗壮 |
| `.identity` | 条件关闭玻璃（滚动性能等） |
| `.glass` / `.glassProminent` buttonStyle | 标准/主按钮 |

**禁止**：内容色块、配方行、大段说明文字整块套玻璃。

### 3.3 滚动边缘效果（Scroll Edge）

- 系统 Toolbar/Tab 默认有边缘模糊，保证玻璃下滚动时控件仍可读。
- 自定义顶/底栏若压住滚动内容，注册 scroll edge，或改回系统栏。
- 密集浮动 UI 可调：

```swift
ScrollView { /* 色板内容 */ }
    .scrollEdgeEffectStyle(.hard, for: .top) // 需要更强分隔时
```

---

## 4. 同心度与几何（Concentricity）

嵌套圆角：**内圆角由外容器圆角减去 padding 推导**，不要手写两套不相关 radius。

```swift
// 与父容器（含设备圆角 / Sheet 圆角）同心
ConcentricRectangle()

// 或玻璃形状
.glassEffect(.regular, in: .rect(corners: .concentric))
```

| 场景 | 做法 |
|------|------|
| Sheet 底部主按钮 | 与 sheet 底角同心 |
| 色板缩略图在圆角卡片内 | 内缩 `md`，内角用 containerConcentric |
| 胶囊控件 | 默认 `.capsule`，与系统控件家族一致 |

---

## 5. 空间关系与 Continuity（连续性）

### 5.1 呈现必须有来源

操作表、确认框、子页面应从触发控件生长，而非无来源滑入。

```swift
@Namespace private var zoomNS

Button { showSheet = true } label: {
    Image(systemName: "slider.horizontal.3")
}
.matchedTransitionSource(id: "mixer-filters", in: zoomNS)

.sheet(isPresented: $showSheet) {
    FilterSheet()
        .navigationTransition(.zoom(sourceID: "mixer-filters", in: zoomNS))
}
```

同理：`confirmationDialog` 挂在触发 `Button` 上；Menu 从玻璃按钮展开。

### 5.2 跨屏连续性

| 维度 | 要求 |
|------|------|
| 导航 | 同一 Tab 内用 `NavigationStack` push；跨主任务用 Tab，不重置无意义状态 |
| 动效 | 共享元素用 `matchedGeometryEffect` / glass `glassEffectID` |
| 品牌色 | Accent 统一（建议 `#FF9900` / `.orange`），Light/Dark 都可读 |
| 文案与图标 | SF Symbols + 语义文案；中/英/日与 Web `translations` 对齐 |
| 多设备 | iPhone 先；iPad 可 `NavigationSplitView`；visionOS 预留，不先做自定义玻璃狂魔 |

### 5.3 Tab 行为（GK-Mixer 推荐）

```swift
TabView {
    Tab("混色台", systemImage: "flask.fill") { MixerWorkbenchView() }
    Tab("调色", systemImage: "circle.grid.cross.fill") { TuningWorkbenchView() }
    Tab("调色板", systemImage: "swatchpalette.fill") { PaletteView() }
    Tab("设置", systemImage: "gearshape") { SettingsView() }
}
.tint(.orange)
.tabBarMinimizeBehavior(.onScrollDown) // 浏览大色板时让内容成为主角
```

混色进行中的紧凑控件可用 `.tabViewBottomAccessory`（类似系统播放条），按 `tabViewBottomAccessoryPlacement` 做 compact/full 两套布局。

---

## 6. 边缘与过渡

| 旧 Web 习惯 | Liquid Glass / iOS 做法 |
|-------------|-------------------------|
| `border` / `divide-y` | 去掉；靠间距、分组、scroll edge |
| 固定顶栏底色 | 系统 Toolbar 玻璃 + scroll edge |
| 底栏抽屉硬滑入 | Sheet inset 玻璃；或从按钮 zoom |
| 侧栏遮罩厚重 | 内嵌玻璃侧栏，内容可在下方延伸；大图用 `.backgroundExtensionEffect()` |
| 页面硬切 | `navigationTransition` / glass morph |

半高 Sheet 默认 inset；全高时玻璃逐渐变实并贴边——不要强行自定义破坏该过渡。

---

## 7. 多外观支持（Light / Dark / 对比度）

### 7.1 颜色

- 文本：`Color.primary` / `.secondary`（或 UIKit 语义 `label` / `secondaryLabel`）
- 背景：`Color(.systemBackground)` / `.secondarySystemBackground` / `.tertiarySystemBackground`
- 强调：Asset Catalog 配 Light/Dark；或 `Color.accentColor`
- **禁止**硬编码 `#FFFFFF` / `#000000` 铺底

### 7.2 色块内容特例

混色预览、色板 swatch **必须**显示真实颜料色（绝对色），不受 Dark Mode 反相。周围 chrome（标签、边框、工具）仍用语义色。

```swift
RoundedRectangle(cornerRadius: 12)
    .fill(Color(red: r, green: g, blue: b)) // 真实色
    .overlay(alignment: .bottom) {
        Text(hex)
            .foregroundStyle(.primary) // 标签仍自适应；必要时加薄玻璃底保证对比
            .padding(Spacing.xs)
            .glassEffect(.regular, in: .capsule)
    }
```

### 7.3 验收

- Xcode Preview：`.preferredColorScheme(.light)` / `.dark`
- 设置 → 显示与亮度 → 深色；再开「增强对比度」
- 玻璃上的文字依赖系统 vibrant，勿再叠一层半透明黑遮罩“救命”

---

## 8. 触控与交互

| 规则 | 标准 |
|------|------|
| 最小热区 | 44×44 pt |
| 主操作位置 | 拇指标区（底部 Toolbar / Tab 附近） |
| 系统手势 | 不拦截边缘返回、Sheet 下滑关闭 |
| 列表 | 支持合理的 swipeActions；破坏性用红色 + 确认 |
| 取色/混色拖拽 | 自定义手势可加，但勿挡住滚动与返回 |
| 玻璃交互 | 可点控件加 `.interactive()`；系统按钮用 `.glass` / `.glassProminent` |
| 触感 | 选色确认 `UISelectionFeedbackGenerator`；完成配方 `notification(.success)`；克制使用 |
| 反馈 | 按下缩放/闪烁交给玻璃交互，勿再叠一套 CSS 式 shadow 动画 |

---

## 9. 控件与工具栏细节

```swift
.toolbar {
    ToolbarItem { ShareLink(...) }
    ToolbarSpacer(.fixed)
    ToolbarItem { Button("收藏", systemImage: "heart") { } }
    ToolbarItem { Button("加入配方", systemImage: "plus") { } }
    ToolbarSpacer(.fixed)
    ToolbarItem { Button("检查器", systemImage: "sidebar.right") { } }
}
```

- 相关操作同一玻璃组；用 `ToolbarSpacer` 分组。
- 头像等独立项：`.sharedBackgroundVisibility(.hidden)`。
- 角标：`.badge(n)`。
- 搜索：`.searchable`；非核心搜索可用 `.searchToolbarBehavior(.minimize)`。

按钮：

```swift
Button("开始混合") { }
    .buttonStyle(.glassProminent)

Button("重置") { }
    .buttonStyle(.glass)
```

---

## 10. Web → Native 改造对照表

| Web (miniwebtools) | SwiftUI / Liquid Glass |
|--------------------|-------------------------|
| 顶部自定义 Header + CSS blur | `NavigationStack` + 系统 Toolbar |
| 底部 Tab 仿造 | `TabView` + SF Symbols |
| Card + shadow + border | 内容直接铺在背景；分组用 `Section` |
| Modal `fixed` 底抽屉 | `.sheet` + detents；zoom 自来源 |
| `position:absolute` 浮动钮 | `safeAreaInset` / `toolbar` / `glassEffect` 浮动层 |
| Tailwind 色板 chrome | 语义色；仅 swatch 用绝对色 |
| anime.js 过渡 | 系统 transition / glass morph |
| 自定义滚动吸顶条 | 系统栏 + scroll edge，删自定义吸顶背景 |

---

## 11. 页面级验收清单（每屏合并前勾选）

**结构**

- [ ] 使用标准 `Tab` / `Navigation` / `Sheet`，无汉堡菜单
- [ ] 无导航系统栏的自定义不透明背景
- [ ] 玻璃只出现在功能层；内容层干净

**几何与间距**

- [ ] 边距落在 8 的倍数 token 上
- [ ] 嵌套圆角同心（或 capsule）
- [ ] Safe Area + 44pt 热区通过

**外观与可读**

- [ ] Light / Dark / 增强对比度均可读
- [ ] 色块真实色正确；标签有足够对比
- [ ] Dynamic Type 最大档不裁切主操作

**运动与空间**

- [ ] Sheet/Dialog 有明确触发来源
- [ ] 滚动时 toolbar/tab 仍可读（scroll edge）
- [ ] 未破坏系统返回/下滑手势

**玻璃专项**

- [ ] 多块自定义玻璃包在同一 `GlassEffectContainer`
- [ ] 无“满屏玻璃”或内容卡片玻璃化
- [ ] Tint 仅语义（混色强调 / 危险红等）

---

## 12. 推荐文件落点（Swift 工程）

```
GK-Mixer/GK-Mixer/
├── Design/
│   ├── Spacing.swift          # 间距 token
│   ├── Colors.swift           # 语义色 + Accent
│   └── Components.swift       # 内容层与功能层共享组件
├── Models/
│   └── PaletteModels.swift    # SwiftData 色卡、分类、双颜料体系 Mixbox 与 RAL 快照
├── State/
│   ├── PaletteStore.swift     # 去重、分类、搜索、持久化
│   ├── WorkbenchStore.swift   # 自动分解、RAL 与待用配方状态
│   └── BasicMixerStore.swift  # 基础 8 色混合状态
├── Services/
│   ├── ColorAlgorithmRuntime.swift # JavaScriptCore 类型安全桥
│   ├── MixboxEngine.swift
│   └── MixboxRecipeSolver.swift
├── Resources/
│   └── gk-color-algorithms.js # Web TS 算法离线 Bundle
├── ContentView.swift          # TabView + minimize + tint
└── Views/                     # 四 Tab；优先系统组件
```

本文件路径：`GK-Mixer/LIQUID_GLASS_UI_REFERENCE.md` — 实现与 PR 审查以本文为准。

---

## 13. 官方锚点（深入时查阅）

| 主题 | URL |
|------|-----|
| Liquid Glass | https://developer.apple.com/documentation/technologyoverviews/liquid-glass |
| Adopting Liquid Glass | https://developer.apple.com/documentation/technologyoverviews/adopting-liquid-glass |
| App Design and UI | https://developer.apple.com/documentation/TechnologyOverviews/app-design-and-ui |
| SwiftUI apps | https://developer.apple.com/documentation/technologyoverviews/swiftui |
| Interface fundamentals | https://developer.apple.com/documentation/technologyoverviews/interface-fundamentals |
| HIG | https://developer.apple.com/design/human-interface-guidelines |
| Designing for iOS | https://developer.apple.com/design/human-interface-guidelines/designing-for-ios |
| WWDC25 Get to know the new design system | https://developer.apple.com/videos/play/wwdc2025/356/ |
| WWDC25 Build a SwiftUI app with the new design | https://developer.apple.com/videos/play/wwdc2025/323/ |

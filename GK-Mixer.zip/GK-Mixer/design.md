---promptzy---
# METADATA (do not edit above or below the delimiters)
title: "design"
collections: ["ios-GK-mixer/GK-Mixer"]
tags: []
variables: []
created: "2026-05-13"
updated: "2026-05-13"
favorite: false
rating: 0
uses: 0
version: 1
versions: []
---promptzy---

# GK Paint Mixing Simulator - iOS 26 App Design Document

## 1. Project Overview & Functional Classification

The GK Mixer app translates digital color into physical paint mixing formulations using realistic pigment physics (Kubelka-Munk theory). 

### 1.1 Core Functional Modules
1. **Visual Input & Analysis (Vision & AI)**
   - **AR Color Extraction**: Live camera feed with AR overlays to pick colors from real-world objects or photos.
   - **Smart Palette AI**: Apple Intelligence powered extraction of up to 8 prominent colors from an image.
   - **Color Space Engine**: Deep integration with iOS Display P3 native APIs, with sRGB and Adobe RGB toggles. Gamut mapping warnings using spatial UI indicators.
   - **Color Analytics**: Real-time breakdown into RGB, CMYK, HSB, and LAB data points.

2. **Paint Mixing Engine (Physics Simulation)**
   - **Mixbox Core**: Kubelka-Munk simulation for real pigment blending (e.g., Blue + Yellow = Green).
   - **Paint Database Matching**: On-device machine learning to find the closest matches (ΔE) in Mr. Hobby, Gaia, Jumpwind, and Gunze databases.
   - **Recipe Generator**: Calculates exact paint ratios and total ml required.

3. **Interactive Mixing Interfaces**
   - **Spatial Radial Mixer**: A gesture-heavy, circular mixing interface. Users drag paint blobs into a central "well", leveraging physics-based fluid animations.
   - **Basic Color Mixer**: A streamlined, quick-access palette of foundational colors (Gaia/Process CMY) for rapid testing.
   - **Professional Mode**: Fine-tuning via CMYK-like subtraction and additive base paints.

---

## 2. iOS 26 UI/UX Design System

To adapt this into a modern iOS 26 application, we leverage the latest Apple design paradigms: **Fluid Spatial UI**, **Dynamic Island 4.0**, **Apple Intelligence**, and **Advanced Haptics**.

### 2.1 Visual Aesthetic (The "Glass & Paint" Theme)
*   **Materials**: Widespread use of `ultraThinMaterial` and `regularMaterial` with high blur radius to let the vibrant paint colors bleed through the UI as diffuse glows.
*   **Typography**: SF Pro Rounded for values and measurements, providing a slightly softer, more approachable feel akin to the "Macaron" aesthetic of the web app.
*   **Color Palette**: The UI itself is stark monochrome (true black/white) relying entirely on the user's selected paint colors to provide the accent coloring dynamically.

### 2.2 Key Interface Components

#### A. Main Dashboard & AR View
*   **Layout**: Edge-to-edge camera view by default. A floating, translucent "dock" at the bottom houses the 8 extracted color slots.
*   **Interaction**: Tap and hold on the viewfinder invokes a localized magnifier (Loupe) that snaps to pixels. 
*   **Apple Intelligence**: A Siri-like glowing orb button suggests color palettes based on the current scene's mood.

#### B. The Radial Mixer (Hero Interaction)
*   **Spatial UI**: The radial mixer is a 3D-like, fluid interface. Central mixing area acts as a liquid droplet. 
*   **Gestures**: Users pull smaller droplets (sliders) from the perimeter into the center. The resistance of the drag is tied to Core Haptics (feeling the "thickness" of the paint).
*   **Dynamic Island**: When interacting with the radial mixer, the Dynamic Island expands to show the current total volume (e.g., "34 / 60 ml") and the real-time ΔE distance to the target color.

#### C. Paint Recipe Card (Bottom Sheet)
*   **Presentation**: A detent-based bottom sheet that snaps to 30%, 60%, and 100% height.
*   **Data Vis**: Uses colorful, pill-shaped progress bars to denote paint ratios.
*   **Live Activities**: If the user minimizes the app while at their workbench, the paint recipe becomes a Live Activity on the Lock Screen, showing the exact drop counts or ml ratios needed so they don't need to unlock their phone with messy hands.

#### D. Database & Brand Matching 
*   **Fluid Carousels**: Swipe through horizontal, interlocking cards showing matching paints from Gaia, Mr. Hobby, etc.
*   **Out-of-Gamut Warning**: If a physical paint cannot reproduce the digital color, the UI element subtly pulses with a red-orange aura, and haptic feedback alerts the user.

### 2.3 System Integrations (iOS 26 Specifics)
1.  **Dynamic Island Integration**: 
    *   *Idle*: Shows the current active target color.
    *   *Active*: Displays mixing progression, out-of-gamut alerts, and brand match confidence scores.
2.  **App Intents & Siri**: "Siri, mix a recipe for neon pink using Gaia paints."
### 2.4 Tab Bar Navigation (底部栏位功能分类)

To provide intuitive navigation for iOS 26, the application utilizes a native Floating Tab Bar (a modern iOS paradigm that adapts dynamically). The features are categorized into five distinct tabs:

1. **📷 Extract (拾色器)**
   * **Core Function**: Visual Input & Analysis.
   * **UI Components**: AR Camera feed, Photo Library picker, Smart Palette AI extraction results.
   * **Quick Actions**: Tap to freeze frame, drag to extract prominent colors into the temporary "Color Dock".

2. **🧪 Mixer (混色台) [Default Home Tab]**
   * **Core Function**: The primary interactive mixing workspace.
   * **UI Components**: Swipeable views between **Radial Mixer** (spatial physics blending), **Basic Mixer** (quick presets), and **Pro Mode** (CMYK fine-tuning).
   * **Dynamic Integration**: Syncs directly with the Dynamic Island to show real-time ΔE changes as you drag sliders.

3. **📚 Paints (漆料库)**
   * **Core Function**: Database management and brand matching.
   * **UI Components**: Browsable catalogs for Gaia, Mr. Hobby, Jumpwind, and Gunze. Includes Gamut Validation warnings and exact HSB/LAB color analytics.
   * **Search**: Global search for specific paint codes (e.g., "Gaia 001") with Apple Intelligence fuzzy matching.

4. **📝 Recipes (我的配方)**
   * **Core Function**: Saving and executing mixing formulas.
   * **UI Components**: Grid/List view of saved recipes. Tap to expand into the Recipe Card (Bottom Sheet).
   * **Actionable**: Initiate a "Mixing Session" from here, which triggers the iOS Live Activity on the Lock Screen for hands-free reference at the workbench.

5. **⚙️ Settings (设置)**
   * **Core Function**: App configuration and iOS system integrations.
   * **UI Components**: Color space toggles (sRGB vs Display P3), default bottle volume settings, Siri App Intents configuration, and Haptic feedback intensity.